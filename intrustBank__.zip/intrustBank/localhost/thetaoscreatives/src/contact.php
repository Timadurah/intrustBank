<style>
    *{
        background-color: #ffc0cb1c;
    }
</style>

<!DOCTYPE html>
<html lang="en-US">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script>
        class RocketLazyLoadScripts {
            constructor(e) {
                (this.triggerEvents = e),
                (this.eventOptions = {
                    passive: !0
                }),
                (this.userEventListener = this.triggerListener.bind(this)),
                (this.delayedScripts = {
                    normal: [],
                    async: [],
                    defer: []
                }),
                (this.allJQueries = []);
            }
            _addUserInteractionListener(e) {
                this.triggerEvents.forEach((t) =>
                    window.addEventListener(t, e.userEventListener, e.eventOptions)
                );
            }
            _removeUserInteractionListener(e) {
                this.triggerEvents.forEach((t) =>
                    window.removeEventListener(t, e.userEventListener, e.eventOptions)
                );
            }
            triggerListener() {
                this._removeUserInteractionListener(this),
                    "loading" === document.readyState ?
                    document.addEventListener(
                        "DOMContentLoaded",
                        this._loadEverythingNow.bind(this)
                    ) :
                    this._loadEverythingNow();
            }
            async _loadEverythingNow() {
                this._delayEventListeners(),
                    this._delayJQueryReady(this),
                    this._handleDocumentWrite(),
                    this._registerAllDelayedScripts(),
                    this._preloadAllScripts(),
                    await this._loadScriptsFromList(this.delayedScripts.normal),
                    await this._loadScriptsFromList(this.delayedScripts.defer),
                    await this._loadScriptsFromList(this.delayedScripts.async),
                    await this._triggerDOMContentLoaded(),
                    await this._triggerWindowLoad(),
                    window.dispatchEvent(new Event("rocket-allScriptsLoaded"));
            }
            _registerAllDelayedScripts() {
                document
                    .querySelectorAll("script[type=rocketlazyloadscript]")
                    .forEach((e) => {
                        e.hasAttribute("src") ?
                            e.hasAttribute("async") && !1 !== e.async ?
                            this.delayedScripts.async.push(e) :
                            (e.hasAttribute("defer") && !1 !== e.defer) ||
                            "module" === e.getAttribute("data-rocket-type") ?
                            this.delayedScripts.defer.push(e) :
                            this.delayedScripts.normal.push(e) :
                            this.delayedScripts.normal.push(e);
                    });
            }
            async _transformScript(e) {
                return (
                    await this._requestAnimFrame(),
                    new Promise((t) => {
                        const n = document.createElement("script");
                        let r;
                        [...e.attributes].forEach((e) => {
                                let t = e.nodeName;
                                "type" !== t &&
                                    ("data-rocket-type" === t &&
                                        ((t = "type"), (r = e.nodeValue)),
                                        n.setAttribute(t, e.nodeValue));
                            }),
                            e.hasAttribute("src") ?
                            (n.addEventListener("load", t),
                                n.addEventListener("error", t)) :
                            ((n.text = e.text), t()),
                            e.parentNode.replaceChild(n, e);
                    })
                );
            }
            async _loadScriptsFromList(e) {
                const t = e.shift();
                return t ?
                    (await this._transformScript(t), this._loadScriptsFromList(e)) :
                    Promise.resolve();
            }
            _preloadAllScripts() {
                var e = document.createDocumentFragment();
                [
                    ...this.delayedScripts.normal,
                    ...this.delayedScripts.defer,
                    ...this.delayedScripts.async,
                ].forEach((t) => {
                        const n = t.getAttribute("src");
                        if (n) {
                            const t = document.createElement("link");
                            (t.href = n),
                            (t.rel = "preload"),
                            (t.as = "script"),
                            e.appendChild(t);
                        }
                    }),
                    document.head.appendChild(e);
            }
            _delayEventListeners() {
                let e = {};

                function t(t, n) {
                    !(function(t) {
                        function n(n) {
                            return e[t].eventsToRewrite.indexOf(n) >= 0 ? "rocket-" + n : n;
                        }
                        e[t] ||
                            ((e[t] = {
                                    originalFunctions: {
                                        add: t.addEventListener,
                                        remove: t.removeEventListener,
                                    },
                                    eventsToRewrite: [],
                                }),
                                (t.addEventListener = function() {
                                    (arguments[0] = n(arguments[0])),
                                    e[t].originalFunctions.add.apply(t, arguments);
                                }),
                                (t.removeEventListener = function() {
                                    (arguments[0] = n(arguments[0])),
                                    e[t].originalFunctions.remove.apply(t, arguments);
                                }));
                    })(t),
                    e[t].eventsToRewrite.push(n);
                }

                function n(e, t) {
                    let n = e[t];
                    Object.defineProperty(e, t, {
                        get: () => n || function() {},
                        set(r) {
                            e["rocket" + t] = n = r;
                        },
                    });
                }
                t(document, "DOMContentLoaded"),
                    t(window, "DOMContentLoaded"),
                    t(window, "load"),
                    t(window, "pageshow"),
                    t(document, "readystatechange"),
                    n(document, "onreadystatechange"),
                    n(window, "onload"),
                    n(window, "onpageshow");
            }
            _delayJQueryReady(e) {
                let t = window.jQuery;
                Object.defineProperty(window, "jQuery", {
                    get: () => t,
                    set(n) {
                        if (n && n.fn && !e.allJQueries.includes(n)) {
                            n.fn.ready = n.fn.init.prototype.ready = function(t) {
                                e.domReadyFired ?
                                    t.bind(document)(n) :
                                    document.addEventListener("rocket-DOMContentLoaded", () =>
                                        t.bind(document)(n)
                                    );
                            };
                            const t = n.fn.on;
                            (n.fn.on = n.fn.init.prototype.on =
                                function() {
                                    if (this[0] === window) {
                                        function e(e) {
                                            return e
                                                .split(" ")
                                                .map((e) =>
                                                    "load" === e || 0 === e.indexOf("load.") ?
                                                    "rocket-jquery-load" :
                                                    e
                                                )
                                                .join(" ");
                                        }
                                        "string" == typeof arguments[0] ||
                                            arguments[0] instanceof String ?
                                            (arguments[0] = e(arguments[0])) :
                                            "object" == typeof arguments[0] &&
                                            Object.keys(arguments[0]).forEach((t) => {
                                                delete Object.assign(arguments[0], {
                                                    [e(t)]: arguments[0][t],
                                                })[t];
                                            });
                                    }
                                    return t.apply(this, arguments), this;
                                }),
                            e.allJQueries.push(n);
                        }
                        t = n;
                    },
                });
            }
            async _triggerDOMContentLoaded() {
                (this.domReadyFired = !0),
                await this._requestAnimFrame(),
                    document.dispatchEvent(new Event("rocket-DOMContentLoaded")),
                    await this._requestAnimFrame(),
                    window.dispatchEvent(new Event("rocket-DOMContentLoaded")),
                    await this._requestAnimFrame(),
                    document.dispatchEvent(new Event("rocket-readystatechange")),
                    await this._requestAnimFrame(),
                    document.rocketonreadystatechange &&
                    document.rocketonreadystatechange();
            }
            async _triggerWindowLoad() {
                await this._requestAnimFrame(),
                    window.dispatchEvent(new Event("rocket-load")),
                    await this._requestAnimFrame(),
                    window.rocketonload && window.rocketonload(),
                    await this._requestAnimFrame(),
                    this.allJQueries.forEach((e) =>
                        e(window).trigger("rocket-jquery-load")
                    ),
                    window.dispatchEvent(new Event("rocket-pageshow")),
                    await this._requestAnimFrame(),
                    window.rocketonpageshow && window.rocketonpageshow();
            }
            _handleDocumentWrite() {
                const e = new Map();
                document.write = document.writeln = function(t) {
                    const n = document.currentScript,
                        r = document.createRange(),
                        i = n.parentElement;
                    let o = e.get(n);
                    void 0 === o && ((o = n.nextSibling), e.set(n, o));
                    const a = document.createDocumentFragment();
                    r.setStart(a, 0),
                        a.appendChild(r.createContextualFragment(t)),
                        i.insertBefore(a, o);
                };
            }
            async _requestAnimFrame() {
                return new Promise((e) => requestAnimationFrame(e));
            }
            static run() {
                const e = new RocketLazyLoadScripts([
                    "keydown",
                    "mousemove",
                    "touchmove",
                    "touchstart",
                    "touchend",
                    "wheel",
                ]);
                e._addUserInteractionListener(e);
            }
        }
        RocketLazyLoadScripts.run();
    </script>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <title>Thetaoscreatives - Printing service company</title>
    <meta name="robots" content="max-image-preview:large" />
    <link rel="dns-prefetch" href="http://fonts.googleapis.com/" />
    <link rel="dns-prefetch" href="http://s.w.org/" />
    <link rel="alternate" type="application/rss+xml" title="Printec &raquo; Feed" href="https://demo2.pavothemes.com/printec/feed/" />
    <link rel="alternate" type="application/rss+xml" title="Printec &raquo; Comments Feed" href="https://demo2.pavothemes.com/printec/comments/feed/" />

    <link rel="stylesheet" id="wcdp-design-css-css" href="../wp-content/plugins/wc-designer-pro/assets/css/wcdp-design.mincdc2.css?ver=1.9.24" media="all" />
    <link rel="stylesheet" id="spectrum-css-css" href="../wp-content/plugins/wc-designer-pro/assets/css/spectrum.mincdc2.css?ver=1.9.24" media="all" />
    <link rel="stylesheet" id="mCustomScrollbar-css-css" href="../wp-content/plugins/wc-designer-pro/assets/css/jquery.mCustomScrollbar.mincdc2.css?ver=1.9.24" media="all" />
    <link rel="stylesheet" id="jbox-css-css" href="../wp-content/plugins/wc-designer-pro/assets/css/jBox.mincdc2.css?ver=1.9.24" media="all" />
    <link rel="stylesheet" id="cropper-css-css" href="../wp-content/plugins/wc-designer-pro/assets/css/cropper.mincdc2.css?ver=1.9.24" media="all" />
    <style id="wp-emoji-styles-inline-css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 0.07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel="stylesheet" id="wp-block-library-css" href="../wp-includes/css/dist/block-library/style.minadc6.css?ver=6.5.5" media="all" />
    <style id="wp-block-library-theme-inline-css">
        .wp-block-audio figcaption {
            color: #555;
            font-size: 13px;
            text-align: center;
        }

        .is-dark-theme .wp-block-audio figcaption {
            color: #ffffffa6;
        }

        .wp-block-audio {
            margin: 0 0 1em;
        }

        .wp-block-code {
            border: 1px solid #ccc;
            border-radius: 4px;
            font-family: Menlo, Consolas, monaco, monospace;
            padding: 0.8em 1em;
        }

        .wp-block-embed figcaption {
            color: #555;
            font-size: 13px;
            text-align: center;
        }

        .is-dark-theme .wp-block-embed figcaption {
            color: #ffffffa6;
        }

        .wp-block-embed {
            margin: 0 0 1em;
        }

        .blocks-gallery-caption {
            color: #555;
            font-size: 13px;
            text-align: center;
        }

        .is-dark-theme .blocks-gallery-caption {
            color: #ffffffa6;
        }

        .wp-block-image figcaption {
            color: #555;
            font-size: 13px;
            text-align: center;
        }

        .is-dark-theme .wp-block-image figcaption {
            color: #ffffffa6;
        }

        .wp-block-image {
            margin: 0 0 1em;
        }

        .wp-block-pullquote {
            border-bottom: 4px solid;
            border-top: 4px solid;
            color: currentColor;
            margin-bottom: 1.75em;
        }

        .wp-block-pullquote cite,
        .wp-block-pullquote footer,
        .wp-block-pullquote__citation {
            color: currentColor;
            font-size: 0.8125em;
            font-style: normal;
            text-transform: uppercase;
        }

        .wp-block-quote {
            border-left: 0.25em solid;
            margin: 0 0 1.75em;
            padding-left: 1em;
        }

        .wp-block-quote cite,
        .wp-block-quote footer {
            color: currentColor;
            font-size: 0.8125em;
            font-style: normal;
            position: relative;
        }

        .wp-block-quote.has-text-align-right {
            border-left: none;
            border-right: 0.25em solid;
            padding-left: 0;
            padding-right: 1em;
        }

        .wp-block-quote.has-text-align-center {
            border: none;
            padding-left: 0;
        }

        .wp-block-quote.is-large,
        .wp-block-quote.is-style-large,
        .wp-block-quote.is-style-plain {
            border: none;
        }

        .wp-block-search .wp-block-search__label {
            font-weight: 700;
        }

        .wp-block-search__button {
            border: 1px solid #ccc;
            padding: 0.375em 0.625em;
        }

        :where(.wp-block-group.has-background) {
            padding: 1.25em 2.375em;
        }

        .wp-block-separator.has-css-opacity {
            opacity: 0.4;
        }

        .wp-block-separator {
            border: none;
            border-bottom: 2px solid;
            margin-left: auto;
            margin-right: auto;
        }

        .wp-block-separator.has-alpha-channel-opacity {
            opacity: 1;
        }

        .wp-block-separator:not(.is-style-wide):not(.is-style-dots) {
            width: 100px;
        }

        .wp-block-separator.has-background:not(.is-style-dots) {
            border-bottom: none;
            height: 1px;
        }

        .wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots) {
            height: 2px;
        }

        .wp-block-table {
            margin: 0 0 1em;
        }

        .wp-block-table td,
        .wp-block-table th {
            word-break: normal;
        }

        .wp-block-table figcaption {
            color: #555;
            font-size: 13px;
            text-align: center;
        }

        .is-dark-theme .wp-block-table figcaption {
            color: #ffffffa6;
        }

        .wp-block-video figcaption {
            color: #555;
            font-size: 13px;
            text-align: center;
        }

        .is-dark-theme .wp-block-video figcaption {
            color: #ffffffa6;
        }

        .wp-block-video {
            margin: 0 0 1em;
        }

        .wp-block-template-part.has-background {
            margin-bottom: 0;
            margin-top: 0;
            padding: 1.25em 2.375em;
        }
    </style>
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-active-filters-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-add-to-cart-form-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/add-to-cart-form787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-packages-style-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/packages-style787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-all-products-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-products787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-all-reviews-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-reviews787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-attribute-filter-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-breadcrumbs-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/breadcrumbs787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-catalog-sorting-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/catalog-sorting787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-customer-account-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/customer-account787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-featured-category-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-category787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-featured-product-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-product787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-mini-cart-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-price-filter-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-add-to-cart-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-button-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-button787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-categories-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-categories787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-image-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-image-gallery-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image-gallery787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-query-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-query787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-results-count-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-results-count787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-reviews-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-reviews787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-sale-badge-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sale-badge787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-search-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-search787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-sku-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sku787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-stock-indicator-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-stock-indicator787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-summary-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-summary787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-title-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-title787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-rating-filter-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-reviews-by-category-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-category787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-reviews-by-product-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-product787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-product-details-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-details787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-single-product-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/single-product787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-stock-filter-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-cart-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-checkout-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="wc-blocks-style-mini-cart-contents-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="printec-gutenberg-blocks-css" href="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/css/base/gutenberg-blocks787e.css?ver=1714985922" media="all" />
    <style id="classic-theme-styles-inline-css">
        /*! This file is auto-generated */
        .wp-block-button__link {
            color: #fff;
            background-color: #32373c;
            border-radius: 9999px;
            box-shadow: none;
            text-decoration: none;
            padding: calc(0.667em + 2px) calc(1.333em + 2px);
            font-size: 1.125em;
        }

        .wp-block-file__button {
            background: #32373c;
            color: #fff;
            text-decoration: none;
        }
    </style>
    <style id="global-styles-inline-css">
        body {
            --wp--preset--color--black: #000000;
            --wp--preset--color--cyan-bluish-gray: #abb8c3;
            --wp--preset--color--white: #ffffff;
            --wp--preset--color--pale-pink: #f78da7;
            --wp--preset--color--vivid-red: #cf2e2e;
            --wp--preset--color--luminous-vivid-orange: #ff6900;
            --wp--preset--color--luminous-vivid-amber: #fcb900;
            --wp--preset--color--light-green-cyan: #7bdcb5;
            --wp--preset--color--vivid-green-cyan: #00d084;
            --wp--preset--color--pale-cyan-blue: #8ed1fc;
            --wp--preset--color--vivid-cyan-blue: #0693e3;
            --wp--preset--color--vivid-purple: #9b51e0;
            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,
                    rgba(6, 147, 227, 1) 0%,
                    rgb(155, 81, 224) 100%);
            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,
                    rgb(122, 220, 180) 0%,
                    rgb(0, 208, 130) 100%);
            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,
                    rgba(252, 185, 0, 1) 0%,
                    rgba(255, 105, 0, 1) 100%);
            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,
                    rgba(255, 105, 0, 1) 0%,
                    rgb(207, 46, 46) 100%);
            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,
                    rgb(238, 238, 238) 0%,
                    rgb(169, 184, 195) 100%);
            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,
                    rgb(74, 234, 220) 0%,
                    rgb(151, 120, 209) 20%,
                    rgb(207, 42, 186) 40%,
                    rgb(238, 44, 130) 60%,
                    rgb(251, 105, 98) 80%,
                    rgb(254, 248, 76) 100%);
            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg,
                    rgb(255, 206, 236) 0%,
                    rgb(152, 150, 240) 100%);
            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,
                    rgb(254, 205, 165) 0%,
                    rgb(254, 45, 45) 50%,
                    rgb(107, 0, 62) 100%);
            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg,
                    rgb(255, 203, 112) 0%,
                    rgb(199, 81, 192) 50%,
                    rgb(65, 88, 208) 100%);
            --wp--preset--gradient--pale-ocean: linear-gradient(135deg,
                    rgb(255, 245, 203) 0%,
                    rgb(182, 227, 212) 50%,
                    rgb(51, 167, 181) 100%);
            --wp--preset--gradient--electric-grass: linear-gradient(135deg,
                    rgb(202, 248, 128) 0%,
                    rgb(113, 206, 126) 100%);
            --wp--preset--gradient--midnight: linear-gradient(135deg,
                    rgb(2, 3, 129) 0%,
                    rgb(40, 116, 252) 100%);
            --wp--preset--font-size--small: 14px;
            --wp--preset--font-size--medium: 23px;
            --wp--preset--font-size--large: 26px;
            --wp--preset--font-size--x-large: 42px;
            --wp--preset--font-size--normal: 16px;
            --wp--preset--font-size--huge: 37px;
            --wp--preset--spacing--20: 0.44rem;
            --wp--preset--spacing--30: 0.67rem;
            --wp--preset--spacing--40: 1rem;
            --wp--preset--spacing--50: 1.5rem;
            --wp--preset--spacing--60: 2.25rem;
            --wp--preset--spacing--70: 3.38rem;
            --wp--preset--spacing--80: 5.06rem;
            --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
            --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1),
                6px 6px rgba(0, 0, 0, 1);
            --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
        }

        :where(.is-layout-flex) {
            gap: 0.5em;
        }

        :where(.is-layout-grid) {
            gap: 0.5em;
        }

        body .is-layout-flex {
            display: flex;
        }

        body .is-layout-flex {
            flex-wrap: wrap;
            align-items: center;
        }

        body .is-layout-flex>* {
            margin: 0;
        }

        body .is-layout-grid {
            display: grid;
        }

        body .is-layout-grid>* {
            margin: 0;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        .has-black-color {
            color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-color {
            color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-color {
            color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-color {
            color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-color {
            color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-color {
            color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-color {
            color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-color {
            color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-color {
            color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-color {
            color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-color {
            color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-color {
            color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-background-color {
            background-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-background-color {
            background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-background-color {
            background-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-background-color {
            background-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-background-color {
            background-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-background-color {
            background-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-background-color {
            background-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-background-color {
            background-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-background-color {
            background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-background-color {
            background-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-border-color {
            border-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-border-color {
            border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-border-color {
            border-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-border-color {
            border-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-border-color {
            border-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-border-color {
            border-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-border-color {
            border-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-border-color {
            border-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-border-color {
            border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-border-color {
            border-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
        }

        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
        }

        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-orange-to-vivid-red-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
        }

        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
        }

        .has-cool-to-warm-spectrum-gradient-background {
            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
        }

        .has-blush-light-purple-gradient-background {
            background: var(--wp--preset--gradient--blush-light-purple) !important;
        }

        .has-blush-bordeaux-gradient-background {
            background: var(--wp--preset--gradient--blush-bordeaux) !important;
        }

        .has-luminous-dusk-gradient-background {
            background: var(--wp--preset--gradient--luminous-dusk) !important;
        }

        .has-pale-ocean-gradient-background {
            background: var(--wp--preset--gradient--pale-ocean) !important;
        }

        .has-electric-grass-gradient-background {
            background: var(--wp--preset--gradient--electric-grass) !important;
        }

        .has-midnight-gradient-background {
            background: var(--wp--preset--gradient--midnight) !important;
        }

        .has-small-font-size {
            font-size: var(--wp--preset--font-size--small) !important;
        }

        .has-medium-font-size {
            font-size: var(--wp--preset--font-size--medium) !important;
        }

        .has-large-font-size {
            font-size: var(--wp--preset--font-size--large) !important;
        }

        .has-x-large-font-size {
            font-size: var(--wp--preset--font-size--x-large) !important;
        }

        .wp-block-navigation a:where(:not(.wp-element-button)) {
            color: inherit;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        .wp-block-pullquote {
            font-size: 1.5em;
            line-height: 1.6;
        }
    </style>
    <link data-minify="1" rel="stylesheet" id="contact-form-7-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/contact-form-7/includes/css/styles787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/opal-demo/style787e.css?ver=1714985922" media="all" />
    <style id="woocommerce-inline-inline-css">
        .woocommerce form .form-row .required {
            visibility: visible;
        }
    </style>
    <link rel="icon" type="image/png" sizes="32x32" href="./imgs/THE_TAOS_logo-removebg.png" />
    <link data-minify="1" rel="stylesheet" id="dndmfu-wc-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/drag-and-drop-multiple-file-upload-for-woocommerce/assets/css/dnd-upload-wc787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="hfe-style-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-icons-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min787e.css?ver=1714985922" media="all" />
    <link rel="stylesheet" id="elementor-frontend-css" href="../wp-content/uploads/elementor/css/custom-frontend.minb018.css?ver=1714985741" media="all" />
    <link rel="stylesheet" id="swiper-css" href="../wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min48f5.css?ver=5.3.6" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-post-4-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-4787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-global-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/global787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-post-142-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-142d228.css?ver=1714986074" media="all" />
    <link data-minify="1" rel="stylesheet" id="hfe-widgets-style-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-post-1612-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-1612d228.css?ver=1714986074" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-post-457-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-457787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-post-7418-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-7418787e.css?ver=1714985922" media="all" />
    <link rel="stylesheet" id="woo-variation-swatches-css" href="../wp-content/plugins/woo-variation-swatches/assets/css/frontend.min177b.css?ver=1688434790" media="all" />
    <style id="woo-variation-swatches-inline-css">
        :root {
            --wvs-tick: url("data:image/svg+xml;utf8,%3Csvg filter='drop-shadow(0px 0px 2px rgb(0 0 0 / .8))' xmlns='http://www.w3.org/2000/svg'  viewBox='0 0 30 30'%3E%3Cpath fill='none' stroke='%23ffffff' stroke-linecap='round' stroke-linejoin='round' stroke-width='4' d='M4 16L11 23 27 7'/%3E%3C/svg%3E");

            --wvs-cross: url("data:image/svg+xml;utf8,%3Csvg filter='drop-shadow(0px 0px 5px rgb(255 255 255 / .6))' xmlns='http://www.w3.org/2000/svg' width='72px' height='72px' viewBox='0 0 24 24'%3E%3Cpath fill='none' stroke='%23ff0000' stroke-linecap='round' stroke-width='0.6' d='M5 5L19 19M19 5L5 19'/%3E%3C/svg%3E");
            --wvs-single-product-item-width: 30px;
            --wvs-single-product-item-height: 30px;
            --wvs-single-product-item-font-size: 16px;
        }
    </style>
    <link rel="stylesheet" id="hint-css" href="../wp-content/plugins/woo-smart-compare/assets/libs/hint/hint.minadc6.css?ver=6.5.5" media="all" />
    <link rel="stylesheet" id="perfect-scrollbar-css" href="../wp-content/plugins/woo-smart-compare/assets/libs/perfect-scrollbar/css/perfect-scrollbar.minadc6.css?ver=6.5.5" media="all" />
    <link data-minify="1" rel="stylesheet" id="perfect-scrollbar-wpc-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-compare/assets/libs/perfect-scrollbar/css/custom-theme787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="woosc-frontend-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-compare/assets/css/frontend787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="slick-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-quick-view/assets/libs/slick/slick787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="magnific-popup-css" href="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/css/libs/magnific-popup787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="woosq-feather-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-quick-view/assets/libs/feather/feather787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="woosq-frontend-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-quick-view/assets/css/frontend787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="woosw-icons-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-wishlist/assets/css/icons787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="woosw-frontend-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-wishlist/assets/css/frontend787e.css?ver=1714985922" media="all" />
    <style id="woosw-frontend-inline-css">
        .woosw-popup .woosw-popup-inner .woosw-popup-content .woosw-popup-content-bot .woosw-notice {
            background-color: #5fbd74;
        }

        .woosw-popup .woosw-popup-inner .woosw-popup-content .woosw-popup-content-bot .woosw-popup-content-bot-inner a:hover {
            color: #5fbd74;
            border-color: #5fbd74;
        }
    </style>
    <link data-minify="1" rel="stylesheet" id="printec-style-css" href="../wp-content/cache/min/1/printec/wp-content/themes/printec/style787e.css?ver=1714985922" media="all" />
    <style id="printec-style-inline-css">
        body {
            --primary: #7000fe;
            --primary_hover: #8500fe;
            --secondary: #2d61f2;
            --secondary_hover: #2875d9;
            --text: #494f66;
            --text_light: #8f8f8f;
            --accent: #000000;
            --light: #a3a7b6;
            --border: #e8e8e8;
            --border_light: #c1c1c1;
            --background: #f5f7fa;
            --background_light: #f6f6f6;
        }

        @media (max-width: 1440px) {
            body.theme-printec [data-elementor-columns-laptop="1"] .column-item {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .woocommerce.columns-laptop-1 ul.products li.product {
                flex: 0 0 100%;
                max-width: 100%;
            }

            body.theme-printec [data-elementor-columns-laptop="2"] .column-item {
                flex: 0 0 50%;
                max-width: 50%;
            }

            .woocommerce.columns-laptop-2 ul.products li.product {
                flex: 0 0 50%;
                max-width: 50%;
            }

            body.theme-printec [data-elementor-columns-laptop="3"] .column-item {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            .woocommerce.columns-laptop-3 ul.products li.product {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            body.theme-printec [data-elementor-columns-laptop="4"] .column-item {
                flex: 0 0 25%;
                max-width: 25%;
            }

            .woocommerce.columns-laptop-4 ul.products li.product {
                flex: 0 0 25%;
                max-width: 25%;
            }

            body.theme-printec [data-elementor-columns-laptop="5"] .column-item {
                flex: 0 0 20%;
                max-width: 20%;
            }

            .woocommerce.columns-laptop-5 ul.products li.product {
                flex: 0 0 20%;
                max-width: 20%;
            }

            body.theme-printec [data-elementor-columns-laptop="6"] .column-item {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            .woocommerce.columns-laptop-6 ul.products li.product {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            body.theme-printec [data-elementor-columns-laptop="7"] .column-item {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            .woocommerce.columns-laptop-7 ul.products li.product {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            body.theme-printec [data-elementor-columns-laptop="8"] .column-item {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }

            .woocommerce.columns-laptop-8 ul.products li.product {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }
        }

        @media (max-width: 1200px) {
            body.theme-printec [data-elementor-columns-tablet-extra="1"] .column-item {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .woocommerce.columns-tablet-extra-1 ul.products li.product {
                flex: 0 0 100%;
                max-width: 100%;
            }

            body.theme-printec [data-elementor-columns-tablet-extra="2"] .column-item {
                flex: 0 0 50%;
                max-width: 50%;
            }

            .woocommerce.columns-tablet-extra-2 ul.products li.product {
                flex: 0 0 50%;
                max-width: 50%;
            }

            body.theme-printec [data-elementor-columns-tablet-extra="3"] .column-item {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            .woocommerce.columns-tablet-extra-3 ul.products li.product {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            body.theme-printec [data-elementor-columns-tablet-extra="4"] .column-item {
                flex: 0 0 25%;
                max-width: 25%;
            }

            .woocommerce.columns-tablet-extra-4 ul.products li.product {
                flex: 0 0 25%;
                max-width: 25%;
            }

            body.theme-printec [data-elementor-columns-tablet-extra="5"] .column-item {
                flex: 0 0 20%;
                max-width: 20%;
            }

            .woocommerce.columns-tablet-extra-5 ul.products li.product {
                flex: 0 0 20%;
                max-width: 20%;
            }

            body.theme-printec [data-elementor-columns-tablet-extra="6"] .column-item {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            .woocommerce.columns-tablet-extra-6 ul.products li.product {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            body.theme-printec [data-elementor-columns-tablet-extra="7"] .column-item {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            .woocommerce.columns-tablet-extra-7 ul.products li.product {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            body.theme-printec [data-elementor-columns-tablet-extra="8"] .column-item {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }

            .woocommerce.columns-tablet-extra-8 ul.products li.product {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }
        }

        @media (max-width: 1024px) {
            body.theme-printec [data-elementor-columns-tablet="1"] .column-item {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .woocommerce.columns-tablet-1 ul.products li.product {
                flex: 0 0 100%;
                max-width: 100%;
            }

            body.theme-printec [data-elementor-columns-tablet="2"] .column-item {
                flex: 0 0 50%;
                max-width: 50%;
            }

            .woocommerce.columns-tablet-2 ul.products li.product {
                flex: 0 0 50%;
                max-width: 50%;
            }

            body.theme-printec [data-elementor-columns-tablet="3"] .column-item {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            .woocommerce.columns-tablet-3 ul.products li.product {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            body.theme-printec [data-elementor-columns-tablet="4"] .column-item {
                flex: 0 0 25%;
                max-width: 25%;
            }

            .woocommerce.columns-tablet-4 ul.products li.product {
                flex: 0 0 25%;
                max-width: 25%;
            }

            body.theme-printec [data-elementor-columns-tablet="5"] .column-item {
                flex: 0 0 20%;
                max-width: 20%;
            }

            .woocommerce.columns-tablet-5 ul.products li.product {
                flex: 0 0 20%;
                max-width: 20%;
            }

            body.theme-printec [data-elementor-columns-tablet="6"] .column-item {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            .woocommerce.columns-tablet-6 ul.products li.product {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            body.theme-printec [data-elementor-columns-tablet="7"] .column-item {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            .woocommerce.columns-tablet-7 ul.products li.product {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            body.theme-printec [data-elementor-columns-tablet="8"] .column-item {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }

            .woocommerce.columns-tablet-8 ul.products li.product {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }
        }

        @media (max-width: 880px) {
            body.theme-printec [data-elementor-columns-mobile-extra="1"] .column-item {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .woocommerce.columns-mobile-extra-1 ul.products li.product {
                flex: 0 0 100%;
                max-width: 100%;
            }

            body.theme-printec [data-elementor-columns-mobile-extra="2"] .column-item {
                flex: 0 0 50%;
                max-width: 50%;
            }

            .woocommerce.columns-mobile-extra-2 ul.products li.product {
                flex: 0 0 50%;
                max-width: 50%;
            }

            body.theme-printec [data-elementor-columns-mobile-extra="3"] .column-item {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            .woocommerce.columns-mobile-extra-3 ul.products li.product {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            body.theme-printec [data-elementor-columns-mobile-extra="4"] .column-item {
                flex: 0 0 25%;
                max-width: 25%;
            }

            .woocommerce.columns-mobile-extra-4 ul.products li.product {
                flex: 0 0 25%;
                max-width: 25%;
            }

            body.theme-printec [data-elementor-columns-mobile-extra="5"] .column-item {
                flex: 0 0 20%;
                max-width: 20%;
            }

            .woocommerce.columns-mobile-extra-5 ul.products li.product {
                flex: 0 0 20%;
                max-width: 20%;
            }

            body.theme-printec [data-elementor-columns-mobile-extra="6"] .column-item {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            .woocommerce.columns-mobile-extra-6 ul.products li.product {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            body.theme-printec [data-elementor-columns-mobile-extra="7"] .column-item {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            .woocommerce.columns-mobile-extra-7 ul.products li.product {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            body.theme-printec [data-elementor-columns-mobile-extra="8"] .column-item {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }

            .woocommerce.columns-mobile-extra-8 ul.products li.product {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }
        }

        @media (max-width: 767px) {
            body.theme-printec [data-elementor-columns-mobile="1"] .column-item {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .woocommerce.columns-mobile-1 ul.products li.product {
                flex: 0 0 100%;
                max-width: 100%;
            }

            body.theme-printec [data-elementor-columns-mobile="2"] .column-item {
                flex: 0 0 50%;
                max-width: 50%;
            }

            .woocommerce.columns-mobile-2 ul.products li.product {
                flex: 0 0 50%;
                max-width: 50%;
            }

            body.theme-printec [data-elementor-columns-mobile="3"] .column-item {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            .woocommerce.columns-mobile-3 ul.products li.product {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%;
            }

            body.theme-printec [data-elementor-columns-mobile="4"] .column-item {
                flex: 0 0 25%;
                max-width: 25%;
            }

            .woocommerce.columns-mobile-4 ul.products li.product {
                flex: 0 0 25%;
                max-width: 25%;
            }

            body.theme-printec [data-elementor-columns-mobile="5"] .column-item {
                flex: 0 0 20%;
                max-width: 20%;
            }

            .woocommerce.columns-mobile-5 ul.products li.product {
                flex: 0 0 20%;
                max-width: 20%;
            }

            body.theme-printec [data-elementor-columns-mobile="6"] .column-item {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            .woocommerce.columns-mobile-6 ul.products li.product {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%;
            }

            body.theme-printec [data-elementor-columns-mobile="7"] .column-item {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            .woocommerce.columns-mobile-7 ul.products li.product {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%;
            }

            body.theme-printec [data-elementor-columns-mobile="8"] .column-item {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }

            .woocommerce.columns-mobile-8 ul.products li.product {
                flex: 0 0 12.5%;
                max-width: 12.5%;
            }
        }
    </style>
    <link data-minify="1" rel="stylesheet" id="printec-slick-style-css" href="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/css/base/slick787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="printec-slick-theme-style-css" href="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/css/base/slick-theme787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-post-5544-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-5544787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-post-5569-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-5569787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-post-5616-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-5616787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="printec-elementor-css" href="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/css/base/elementor787e.css?ver=1714985922" media="all" />
    <link data-minify="1" rel="stylesheet" id="printec-woocommerce-style-css" href="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/css/woocommerce/woocommerce787e.css?ver=1714985922" media="all" />
    <link rel="stylesheet" id="tooltipster-css" href="../wp-content/themes/printec/assets/css/libs/tooltipster.bundle.min1576.css?ver=1.2.1" media="all" />
    <link data-minify="1" rel="stylesheet" id="printec-child-style-css" href="../wp-content/cache/min/1/printec/wp-content/themes/demo-child/style787e.css?ver=1714985922" media="all" />
    <link rel="stylesheet" id="google-fonts-1-css" href="https://fonts.googleapis.com/css?family=Poppins%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=swap&amp;ver=6.5.5" media="all" />
    <link rel="stylesheet" id="elementor-icons-shared-0-css" href="../wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3" media="all" />
    <link data-minify="1" rel="stylesheet" id="elementor-icons-fa-brands-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min787e.css?ver=1714985922" media="all" />
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
    <script type="text/template" id="tmpl-variation-template">
        <div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
      <div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
      <div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
    </script>
    <script type="text/template" id="tmpl-unavailable-variation-template">
        <p>Sorry, this product is unavailable. Please choose a different combination.</p>
    </script>
    <script src="../wp-includes/js/jquery/jquery.minf43b.js?ver=3.7.1" id="jquery-core-js"></script>
    <script src="../wp-includes/js/jquery/jquery-migrate.min5589.js?ver=3.4.1" id="jquery-migrate-js"></script>
    <script data-minify="1" src="../wp-content/cache/min/1/pr intec/wp-content/plugins/wc-designer-pro/assets/js/webfontloader787e.js?ver=1714985922" id="webfontloader-js-js"></script>
    <script src="../wp-content/plugins/wc-designer-pro/assets/js/lazyload.mincdc2.js?ver=1.9.24" id="lazyload-js-js"></script>
    <script src="../wp-content/plugins/wc-designer-pro/assets/js/jBox.mincdc2.js?ver=1.9.24" id="jbox-js-js"></script>
    <script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/vendor/jarallax787e.js?ver=1714985922" id="jarallax-js"></script>
    <link rel="https://api.w.org/" href="https://demo2.pavothemes.com/printec/wp-json/" />
    <link rel="alternate" type="application/json" href="https://demo2.pavothemes.com/printec/wp-json/wp/v2/pages/142" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://demo2.pavothemes.com/printec/xmlrpc.php?rsd" />

    <link rel="canonical" href="index.php" />
    <link rel="shortlink" href="./" />
    <noscript>
        <style>
            .woocommerce-product-gallery {
                opacity: 1 !important;
            }
        </style>
    </noscript>

    <meta name="generator" content="" />
    <meta name="generator" content="thetaoscreatives" />
    <script type="rocketlazyloadscript">
        function setREVStartSize(e){
      			//window.requestAnimationFrame(function() {
      				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;
      				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;
      				try {
      					var pw = document.getElementById(e.c).parentNode.offsetWidth,
      						newh;
      					pw = pw===0 || isNaN(pw) || (e.l=="fullwidth" || e.layout=="fullwidth") ? window.RSIW : pw;
      					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
      					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
      					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
      					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
      					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
      					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
      					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);
      					if(e.layout==="fullscreen" || e.l==="fullscreen")
      						newh = Math.max(e.mh,window.RSIH);
      					else{
      						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
      						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];
      						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
      						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
      						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];

      						var nl = new Array(e.rl.length),
      							ix = 0,
      							sl;
      						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
      						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
      						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
      						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;
      						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
      						sl = nl[0];
      						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}
      						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);
      						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
      					}
      					var el = document.getElementById(e.c);
      					if (el!==null && el) el.style.height = newh+"px";
      					el = document.getElementById(e.c+"_wrapper");
      					if (el!==null && el) {
      						el.style.height = newh+"px";
      						el.style.display = "block";
      					}
      				} catch(e){
      					console.log("Failure at Presize of Slider:" + e)
      				}
      			//});
      		  };
    </script>
    <script type="rocketlazyloadscript">
        var woocs_is_mobile = 0;
      var woocs_special_ajax_mode = 0;
      var woocs_drop_down_view = "ddslick";
      var woocs_current_currency = {"name":"USD","rate":1,"symbol":"&#36;","position":"left","is_etalon":1,"hide_cents":0,"hide_on_front":0,"rate_plus":"","decimals":2,"separators":"0","description":"USA dollar","flag":"https:\/\/demo2.pavothemes.com\/printec\/wp-content\/plugins\/woocommerce-currency-switcher\/img\/no_flag.png"};
      var woocs_default_currency = {"name":"USD","rate":1,"symbol":"&#36;","position":"left","is_etalon":1,"hide_cents":0,"hide_on_front":0,"rate_plus":"","decimals":2,"separators":"0","description":"USA dollar","flag":"https:\/\/demo2.pavothemes.com\/printec\/wp-content\/plugins\/woocommerce-currency-switcher\/img\/no_flag.png"};
      var woocs_redraw_cart = 1;
      var woocs_array_of_get = '{}';

      woocs_array_no_cents = '["JPY","TWD"]';

      var woocs_ajaxurl = "https://demo2.pavothemes.com/printec/wp-admin/admin-ajax.php";
      var woocs_lang_loading = "loading";
      var woocs_shop_is_cached =0;
    </script>
    <noscript>
        <style id="rocket-lazyload-nojs-css">
            .rll-youtube-player,
            [data-lazy-src] {
                display: none !important;
            }
        </style>
    </noscript>
</head>

<body class="page-template page-template-template-homepage page-template-template-homepage-php page page-id-142 wp-embed-responsive theme-printec woocommerce-no-js ehf-header ehf-footer ehf-template-printec ehf-stylesheet-demo-child woo-variation-swatches wvs-behavior-blur wvs-theme-demo-child wvs-tooltip woocommerce-active product-block-style-1 elementor-default elementor-kit-4 elementor-page elementor-page-142 currency-usd">
    <div id="page" class="hfeed site">
        <header id="masthead" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
            <p class="main-title bhf-hidden" itemprop="headline">
                <a href="./" title="Printec" rel="home">thetaoscreativesc</a>
            </p>
            <div data-elementor-type="wp-post" data-elementor-id="1612" class="elementor elementor-1612">
                <section class="elementor-section elementor-top-section elementor-element elementor-element-b59c06d elementor-section-full_width elementor-section-stretched elementor-section-height-default elementor-section-height-default" data-id="b59c06d" data-element_type="section" id="back-to-top" data-settings='{"stretch_section":"section-stretched","background_background":"classic"}'>
                    <div class="elementor-container elementor-column-gap-no">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c99fe51" data-id="c99fe51" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-96fa17d elementor-widget elementor-widget-text-editor" data-id="96fa17d" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div>
                                            Experience our Art, Creativity and skill of advancing your product

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="elementor-section elementor-top-section elementor-element elementor-element-1cce4ae elementor-section-stretched elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="1cce4ae" data-element_type="section" data-settings='{"stretch_section":"section-stretched","background_background":"classic"}'>
                    <div class="elementor-container elementor-column-gap-no">
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-a31ffde" data-id="a31ffde" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-5fcceaa elementor-widget__width-auto elementor-hidden-desktop elementor-hidden-laptop elementor-hidden-tablet_extra printec-canvas-menu-layout-2 elementor-widget elementor-widget-printec-menu-canvas" data-id="5fcceaa" data-element_type="widget" data-widget_type="printec-menu-canvas.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-canvas-menu-wrapper">
                                            <a href="#" class="menu-mobile-nav-button">
                                                <span class="toggle-text screen-reader-text">Menu</span>
                                                <div class="printec-icon">
                                                    <span class="icon-1"></span>
                                                    <span class="icon-2"></span>
                                                    <span class="icon-3"></span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-63c4993 elementor-widget__width-auto elementor-hidden-tablet elementor-hidden-mobile_extra elementor-hidden-mobile elementor-widget elementor-widget-printec-nav-menu" data-id="63c4993" data-element_type="widget" data-widget_type="printec-nav-menu.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-nav-menu-wrapper">
                                            <nav class="main-navigation" aria-label="Primary Navigation">
                                                <div class="primary-navigation">
                                                    <ul id="menu-1-63c4993" class="menu">
                                                        <li id="menu-item-400" class="menu-item menu-item-type-post_type
                                                         menu-item-object-page menu-item-home current-menu-ancestor
                                                          current-menu-parent current_page_parent current_page_ancestor
                                                           menu-item-400  has-stretchwidth">
                                                            <a href="./"><span class="menu-title">Home</span></a>

                                                        </li>


                                                        <li id="menu-item-6120" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6120">
                                                            <a href="./contact.php"><span class="menu-title">Contact Us</span></a>

                                                        </li>
                                                    </ul>
                                                </div>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-853ac68" data-id="853ac68" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-e7ad9ae elementor-widget__width-auto elementor-widget elementor-widget-site-logo" data-id="e7ad9ae" data-element_type="widget" data-settings='{"align":"center","width":{"unit":"%","size":"","sizes":[]},"width_laptop":{"unit":"px","size":"","sizes":[]},"width_tablet_extra":{"unit":"px","size":"","sizes":[]},"width_tablet":{"unit":"%","size":"","sizes":[]},"width_mobile_extra":{"unit":"px","size":"","sizes":[]},"width_mobile":{"unit":"%","size":"","sizes":[]},"space":{"unit":"%","size":"","sizes":[]},"space_laptop":{"unit":"px","size":"","sizes":[]},"space_tablet_extra":{"unit":"px","size":"","sizes":[]},"space_tablet":{"unit":"%","size":"","sizes":[]},"space_mobile_extra":{"unit":"px","size":"","sizes":[]},"space_mobile":{"unit":"%","size":"","sizes":[]},"image_border_radius":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_laptop":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_tablet_extra":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_tablet":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_mobile_extra":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_mobile":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_laptop":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_tablet_extra":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_tablet":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_mobile_extra":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_mobile":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_space":{"unit":"px","size":0,"sizes":[]},"caption_space_laptop":{"unit":"px","size":"","sizes":[]},"caption_space_tablet_extra":{"unit":"px","size":"","sizes":[]},"caption_space_tablet":{"unit":"px","size":"","sizes":[]},"caption_space_mobile_extra":{"unit":"px","size":"","sizes":[]},"caption_space_mobile":{"unit":"px","size":"","sizes":[]}}' data-widget_type="site-logo.default">
                                    <div class="elementor-widget-container">
                                        <div class="hfe-site-logo">
                                            <a data-elementor-open-lightbox class="elementor-clickable" href="./">
                                                <div class="hfe-site-logo-set">
                                                    <div class="hfe-site-logo-container">
                                                        <img class="hfe-site-logo-img elementor-animation- " style="width:70px;" src="./imgs/THE_TAOS_logo-removebg.png" alt="logo" data-lazy-src="./imgs/THE_TAOS_logo-removebg.png" /><noscript>
                                                            <img class="hfe-site-logo-img elementor-animation- " style="width:50px;" src="./imgs/THE_TAOS_logo-removebg.pngf" alt="logo" /></noscript>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-fd0aa10" data-id="fd0aa10" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-e7adbb0 elementor-widget__width-initial elementor-hidden-mobile_extra elementor-hidden-mobile 
                                search-printec-style-1 elementor-widget elementor-widget-printec-search" data-id="e7adbb0" data-element_type="widget" data-widget_type="printec-search.default">
                                    <div class="elementor-widget-container">
                                        <div class="site-search ajax-search">
                                            <div class="widget woocommerce widget_product_search">
                                                <div class="ajax-search-result d-none"></div>
                                                <form role="search" method="get" class="woocommerce-product-search" action="./products.php">
                                                    <label class="screen-reader-text" for="woocommerce-product-search-field-1">Search for:</label>
                                                    <input type="search" id="woocommerce-product-search-field-1" class="search-field" placeholder="Search products&hellip;" autocomplete="off" value name="s" />
                                                    <button type="submit" value="Search">
                                                        <i class="text-muted fa fa-search"></i>Search
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </header>


<section class="container">
    <div class="col-11 col-lg-8 d-flex align-items-center justify-content-center" style="gap:5;">
        <img src="./imgs/309259800_498015198517216_5098182741483661974_n.jpg" alt="thetaoscreatives" 
        class="col-10 rounded shadow" style="height: auto; max-width :40vw;">
        <div class="col-lg-5 col-10 p-2">
            <h2 style="color:#000;">Lorem ipsum dolor, sit amet consectetur adipisicing elit.</h2>
            <em class="text-muted">Lorem, ipsum dolor.</em>
            <p class="text-dark">Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                Enim commodi consequuntur dicta voluptatum velit vel a. Totam perferendis impedit odit!. 
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo,
                 aperiam praesentium. Dolor commodi rerum facilis repellendus numquam dolorum in assumenda.</p>
        </div>


    </div>
</section>


<div id="content" class="site-content" tabindex="-1">
    <div class="col-full">
        <div class="woocommerce"></div>
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="woocommerce-notices-wrapper"></div>
                <div id="product-112" class="single-product-type-horizontal product type-product post-112 status-publish first onbackorder product_cat-stickers product_tag-cup product_tag-magazine product_tag-poster product_tag-t-shirt has-post-thumbnail featured shipping-taxable purchasable product-type-variable has-default-attributes">

                    <section class="related products">
                        <h2>products</h2>
                        <ul class="products columns-4">



                            


                        </ul>
                    </section>
                </div>
            </main>
        </div>
    </div>
</div>

<div class="footer-width-fixer">
  <div data-elementor-type="wp-post" data-elementor-id="7418" class="elementor elementor-7418">
    <section class="elementor-section elementor-top-section elementor-element elementor-element-665e924 elementor-hidden-desktop elementor-hidden-laptop
     elementor-hidden-tablet_extra elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="665e924" data-element_type="section" data-settings='{"background_background":"classic"}'>
      <div class="elementor-container elementor-column-gap-no">
        <div class="make-column-clickable-elementor elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-7b979b0" style="cursor: pointer" data-column-clickable="./" data-column-clickable-blank="_self" data-id="7b979b0" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-e413d3b elementor-view-default elementor-position-top elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="e413d3b" data-element_type="widget" data-widget_type="icon-box.default">
              <div class="elementor-widget-container">
                <div class="elementor-icon-box-wrapper">
                  <div class="elementor-icon-box-icon">
                    <a class="elementor-icon elementor-animation-" href="./">
                      <i aria-hidden="true" class="fa fa-home"></i>
                    </a>
                  </div>
                  <div class="elementor-icon-box-content">
                    <h3 class="elementor-icon-box-title">
                      <a href="./">
                        Home
                      </a>
                    </h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="make-column-clickable-elementor elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-b8cc6a1" style="cursor: pointer" data-column-clickable="./products.php" data-column-clickable-blank="_self" data-id="b8cc6a1" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-17148a9 elementor-view-default elementor-position-top elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="17148a9" data-element_type="widget" data-widget_type="icon-box.default">
              <div class="elementor-widget-container">
                <div class="elementor-icon-box-wrapper">
                  <div class="elementor-icon-box-icon">
                    <a class="elementor-icon elementor-animation-" href="./products.php">
                      <i aria-hidden="true" class="fa fa-shopping-basket"></i>
                    </a>
                  </div>
                  <div class="elementor-icon-box-content">
                    <h3 class="elementor-icon-box-title">
                      <a href="./products.php">
                        Products
                      </a>
                    </h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-c256c49" data-id="c256c49" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-1a5f824 elementor-widget elementor-widget-printec-search" data-id="1a5f824" data-element_type="widget" data-widget_type="printec-search.default">
              <div class="elementor-widget-container">
                <div class="site-header-search">
                  <a href="#" class="button-search-popup">
                    <i class="fa fa-search"></i>
                    <span class="content">Search</span>
                  </a>
                </div>
                <div class="site-search-popup">
                  <div class="site-search-popup-wrap">
                    <div class="site-search">
                      <form role="search" method="post" class="search-form" action="./products.php">
                        <label>
                          <span class="screen-reader-text">Search for:</span>
                          <input type="search" class="search-field" placeholder="Search &hellip;" value name="s" />
                        </label>
                        <input type="submit" class="search-submit" value="Search" />
                      </form>
                    </div>
                    <a href="#" class="site-search-popup-close">
                      <svg class="close-icon" xmlns="http://www.w3.org/2000/svg" width="23.691" height="22.723" viewBox="0 0 23.691 22.723">
                        <g transform="translate(-126.154 -143.139)">
                          <line x2="23" y2="22" transform="translate(126.5 143.5)" fill="none" stroke="CurrentColor" stroke-width="1"></line>
                          <path d="M0,22,23,0" transform="translate(126.5 143.5)" fill="none" stroke="CurrentColor" stroke-width="1"></path>
                        </g>
                      </svg>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="make-column-clickable-elementor elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-2f3e73b" style="cursor: pointer" data-column-clickable="./contact.php" data-column-clickable-blank="_self" data-id="2f3e73b" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-719234b elementor-view-default elementor-position-top elementor-mobile-position-top elementor-widget elementor-widget-icon-box" data-id="719234b" data-element_type="widget" data-widget_type="icon-box.default">
              <div class="elementor-widget-container">
                <div class="elementor-icon-box-wrapper">
                  <div class="elementor-icon-box-icon">
                    <a class="elementor-icon elementor-animation-" href="./contact.php">
                      <i aria-hidden="true" class="fa fa-envelope"></i>
                    </a>
                  </div>
                  <div class="elementor-icon-box-content">
                    <h3 class="elementor-icon-box-title">
                      <a href="./contact.php">
                        Contact
                      </a>
                    </h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>







<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
  <div class="footer-width-fixer">
    <div data-elementor-type="wp-post" data-elementor-id="457" class="elementor elementor-457">
      <section class="elementor-section elementor-top-section elementor-element elementor-element-9f97762 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9f97762" data-element_type="section" data-settings='{"stretch_section":"section-stretched","background_background":"classic"}'>
        <div class="elementor-container elementor-column-gap-no">
          <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-896925e" data-id="896925e" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
              <section class="elementor-section elementor-inner-section elementor-element elementor-element-b8649e2 elementor-section-height-min-height elementor-section-full_width elementor-section-height-default" data-id="b8649e2" data-element_type="section" data-settings='{"background_background":"classic"}'>
                <div class="elementor-background-overlay"></div>
                <div class="elementor-container elementor-column-gap-no">
                  <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-08ad891" data-id="08ad891" data-element_type="column" data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-54b61ed elementor-widget__width-auto elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile_extra elementor-hidden-mobile elementor-widget elementor-widget-image" data-id="54b61ed" data-element_type="widget" data-widget_type="image.default">
                        <div class="elementor-widget-container">
                          <img width="148" height="148" src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20148%20148'%3E%3C/svg%3E" class="attachment-full size-full wp-image-452" alt data-lazy-srcset="https://demo2.pavothemes.com/printec/wp-content/uploads/2023/02/letter-1.png 148w, https://demo2.pavothemes.com/printec/wp-content/uploads/2023/02/letter-1-100x100.png 100w, https://demo2.pavothemes.com/printec/wp-content/uploads/2023/02/letter-1-50x50.png 50w, https://demo2.pavothemes.com/printec/wp-content/uploads/2023/02/letter-1-96x96.png 96w" data-lazy-sizes="(max-width: 148px) 100vw, 148px" data-lazy-src="../wp-content/uploads/2023/02/letter-1.png" /><noscript><img width="148" height="148" src="../wp-content/uploads/2023/02/letter-1.png" class="attachment-full size-full wp-image-452" alt="" srcset="
                                      https://demo2.pavothemes.com/printec/wp-content/uploads/2023/02/letter-1.png         148w,
                                      https://demo2.pavothemes.com/printec/wp-content/uploads/2023/02/letter-1-100x100.png 100w,
                                      https://demo2.pavothemes.com/printec/wp-content/uploads/2023/02/letter-1-50x50.png    50w,
                                      https://demo2.pavothemes.com/printec/wp-content/uploads/2023/02/letter-1-96x96.png    96w
                                    " sizes="(max-width: 148px) 100vw, 148px" /></noscript>
                        </div>
                      </div>
                      <div class="elementor-element elementor-element-35d0fd0 elementor-widget__width-initial elementor-widget elementor-widget-heading" data-id="35d0fd0" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                          <h2 class="elementor-heading-title elementor-size-default">
                            Sign up for exclusive offers from us
                          </h2>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-dd72c97" data-id="dd72c97" data-element_type="column" data-settings='{"background_background":"classic"}'>
                    <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-4a3f7b8 elementor-widget__width-initial elementor-widget elementor-widget-text-editor" data-id="4a3f7b8" data-element_type="widget" data-widget_type="text-editor.default">
                        <div class="elementor-widget-container">
                          <div>
                            Sign up to your newsletter for all the latest
                            news and our villa exclusives promotion.
                          </div>
                        </div>
                      </div>
                      <div class="elementor-element elementor-element-803df62 elementor-widget elementor-widget-printec-mailchmip" data-id="803df62" data-element_type="widget" data-widget_type="printec-mailchmip.default">
                        <div class="elementor-widget-container">
                          <div class="form-style">
                            <script type="rocketlazyloadscript">
                              (function() {
                                    	window.mc4wp = window.mc4wp || {
                                    		listeners: [],
                                    		forms: {
                                    			on: function(evt, cb) {
                                    				window.mc4wp.listeners.push(
                                    					{
                                    						event   : evt,
                                    						callback: cb
                                    					}
                                    				);
                                    			}
                                    		}
                                    	}
                                    })();
                                  </script>
                            <form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-904" method="post" data-id="904" data-name>
                              <div class="mc4wp-form-fields">
                                <input type="email" name="EMAIL" placeholder="Your name..." required />
                                <button type="submit" value="Submit" class="btn-theme">
                                  <span>subscribe</span>

                                </button>
                              </div>
                              <label style="display: none !important">Leave this field empty if you're human:
                                <input type="text" name="_mc4wp_honeypot" value tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1721491859" /><input type="hidden" name="_mc4wp_form_id" value="904" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" />
                              <div class="mc4wp-response"></div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              <section class="elementor-section elementor-inner-section elementor-element elementor-element-555ad88 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="555ad88" data-element_type="section">
                <div class="elementor-container elementor-column-gap-no">
                  <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-9b50b32" data-id="9b50b32" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-0ba3aba elementor-widget-mobile__width-auto elementor-widget elementor-widget-site-logo" data-id="0ba3aba" data-element_type="widget" data-settings='{"align_mobile":"center","align":"center","width":{"unit":"%","size":"","sizes":[]},"width_laptop":{"unit":"px","size":"","sizes":[]},"width_tablet_extra":{"unit":"px","size":"","sizes":[]},"width_tablet":{"unit":"%","size":"","sizes":[]},"width_mobile_extra":{"unit":"px","size":"","sizes":[]},"width_mobile":{"unit":"%","size":"","sizes":[]},"space":{"unit":"%","size":"","sizes":[]},"space_laptop":{"unit":"px","size":"","sizes":[]},"space_tablet_extra":{"unit":"px","size":"","sizes":[]},"space_tablet":{"unit":"%","size":"","sizes":[]},"space_mobile_extra":{"unit":"px","size":"","sizes":[]},"space_mobile":{"unit":"%","size":"","sizes":[]},"image_border_radius":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_laptop":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_tablet_extra":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_tablet":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_mobile_extra":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"image_border_radius_mobile":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_laptop":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_tablet_extra":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_tablet":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_mobile_extra":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_padding_mobile":{"unit":"px","top":"","right":"","bottom":"","left":"","isLinked":true},"caption_space":{"unit":"px","size":0,"sizes":[]},"caption_space_laptop":{"unit":"px","size":"","sizes":[]},"caption_space_tablet_extra":{"unit":"px","size":"","sizes":[]},"caption_space_tablet":{"unit":"px","size":"","sizes":[]},"caption_space_mobile_extra":{"unit":"px","size":"","sizes":[]},"caption_space_mobile":{"unit":"px","size":"","sizes":[]}}' data-widget_type="site-logo.default">
                        <div class="elementor-widget-container">
                          <div class="hfe-site-logo">
                            <a data-elementor-open-lightbox class="elementor-clickable" href="https://demo2.pavothemes.com/printec">
                              <div class="hfe-site-logo-set">
                                <div class="hfe-site-logo-container">
                                  <img class="hfe-site-logo-img elementor-animation-" src="./imgs/THE_TAOS_logo-removebg.png" alt="logo" data-lazy-src="./imgs/THE_TAOS_logo-removebg.png" style="width: 100px;" /><noscript><img class="hfe-site-logo-img elementor-animation-" src="./imgs/THE_TAOS_logo-removebg.png" style="width: 100px;" alt="logo" /></noscript>
                                </div>
                              </div>
                            </a>
                          </div>
                        </div>
                      </div>
                      <div class="elementor-element elementor-element-77a51a8 elementor-widget__width-initial elementor-widget-mobile__width-inherit elementor-widget elementor-widget-text-editor" data-id="77a51a8" data-element_type="widget" data-widget_type="text-editor.default">
                        <div class="elementor-widget-container">
                          <div>
                            With the decades of experience we got, we guaranty you of best result when you join our company.
                          </div>
                        </div>
                      </div>
                      <div class="elementor-element elementor-element-bcecf8b elementor-shape-circle e-grid-align-left e-grid-align-mobile-center elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="bcecf8b" data-element_type="widget" data-widget_type="social-icons.default">
                        <div class="elementor-widget-container">
                          <div class="elementor-social-icons-wrapper elementor-grid">
                            <span class="elementor-grid-item">
                              <a class="elementor-icon elementor-social-icon elementor-social-icon-facebook-f elementor-animation-shrink elementor-repeater-item-6af4b05" href="https://www.facebook.com/profile.php?id=100087767812366&mibextid=LQQJ4d" target="_blank">
                                <span class="elementor-screen-only">Facebook-f</span>
                                <i class="fab fa-facebook-f"></i>
                              </a>
                            </span>
                            <span class="elementor-grid-item">
                              <a class="elementor-icon elementor-social-icon elementor-social-icon-tiktok elementor-animation-shrink elementor-repeater-item-1ca3919" href="https://www.tiktok.com/@thetaoscreatives?_t=8z87dtgf9ga&_r=1" target="_blank">
                                <span class="elementor-screen-only">Tiktok</span>
                                <i class="fab fa-tiktok"></i>
                              </a>
                            </span>
                            <span class="elementor-grid-item">
                              <a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-animation-shrink elementor-repeater-item-442aee6" href="https://www.instagram.com/thetaoscreatives/" target="_blank">
                                <span class="elementor-screen-only">Instagram</span>
                                <i class="fab fa-instagram"></i>
                              </a>
                            </span>
                            <span class="elementor-grid-item">
                              <a class="elementor-icon elementor-social-icon elementor-social-icon-whatsapp elementor-animation-shrink elementor-repeater-item-6680ca7" href="https://wa.me/message/YSXCC3VVNNNJF1" target="_blank">
                                <span class="elementor-screen-only">whatsapp</span>
                                <i class="fab fa-whatsapp"></i>
                              </a>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-f1b619d" data-id="f1b619d" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-d1395ac elementor-widget elementor-widget-heading" data-id="d1395ac" data-element_type="widget" data-widget_type="heading.default">
                        <div class="elementor-widget-container">
                          <h2 class="elementor-heading-title elementor-size-default">
                            Information
                          </h2>
                        </div>
                      </div>
                      <div class="elementor-element elementor-element-ebd45dc elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="ebd45dc" data-element_type="widget" data-widget_type="icon-list.default">
                        <div class="elementor-widget-container">
                          <ul class="elementor-icon-list-items">
                            <li class="elementor-icon-list-item">
                              <a href="./contact.php">
                                <span class="elementor-icon-list-text">Contact Us</span>
                              </a>
                            </li>
                            <li class="elementor-icon-list-item">
                              <a href="https://demo2.pavothemes.com/printec/shop/">
                                <span class="elementor-icon-list-text">Products</span>
                              </a>
                            </li>
                            
                          
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>


              </section>
              <section class="elementor-section elementor-inner-section elementor-element elementor-element-574c537 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="574c537" data-element_type="section">
                <div class="elementor-container elementor-column-gap-no">
                  <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-fdad35b" data-id="fdad35b" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-d19be5a elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="d19be5a" data-element_type="widget" data-widget_type="divider.default">
                        <div class="elementor-widget-container">
                          <div class="elementor-divider">
                            <span class="elementor-divider-separator">
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              <section class="elementor-section elementor-inner-section elementor-element elementor-element-a63cc5a elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="a63cc5a" data-element_type="section">
                <div class="elementor-container elementor-column-gap-no">
                  <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-935a42c" data-id="935a42c" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                      <div class="elementor-element elementor-element-f8181f9 elementor-widget elementor-widget-text-editor" data-id="f8181f9" data-element_type="widget" data-widget_type="text-editor.default">
                        <div class="elementor-widget-container">
                          <div>
                            Copyright © 2024                            <a href="https://demo2.pavothemes.com/autofiix">thetaoscreatives.</a>
                            All rights reserved
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>


                </div>
              </section>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</footer>
</div>

<div class="printec-overlay"></div>
<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script type="rocketlazyloadscript">
  window.RS_MODULES = window.RS_MODULES || {};
      window.RS_MODULES.modules = window.RS_MODULES.modules || {};
      window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
      window.RS_MODULES.defered = true;
      window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
      window.RS_MODULES.type = 'compiled';
    </script>
<script type="rocketlazyloadscript">
  (function() {function maybePrefixUrlField () {
        const value = this.value.trim()
        if (value !== '' && value.indexOf('http') !== 0) {
          this.value = 'http://' + value
        }
      }

      const urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]')
      for (let j = 0; j < urlFields.length; j++) {
        urlFields[j].addEventListener('blur', maybePrefixUrlField)
      }
      })();
    </script>
<div class="woosc-popup woosc-search">
  <div class="woosc-popup-inner">
    <div class="woosc-popup-content">
      <div class="woosc-popup-content-inner">
        <div class="woosc-popup-close"></div>
        <div class="woosc-search-input">
          <input type="search" id="woosc_search_input" placeholder="Type any keyword to search..." />
        </div>
        <div class="woosc-search-result"></div>
      </div>
    </div>
  </div>
</div>
<div class="woosc-popup woosc-settings">
  <div class="woosc-popup-inner">
    <div class="woosc-popup-content">
      <div class="woosc-popup-content-inner">
        <div class="woosc-popup-close"></div>
        <ul class="woosc-settings-tools">
          <li>
            <label><input type="checkbox" class="woosc-settings-tool" value="hide_similarities" id="woosc_hide_similarities" />
              Hide similarities
            </label>
          </li>
          <li>
            <label><input type="checkbox" class="woosc-settings-tool" value="highlight_differences" id="woosc_highlight_differences" />
              Highlight differences
            </label>
          </li>
        </ul>
        Select the fields to be shown. Others will be hidden. Drag and drop
        to rearrange the order.
        <ul class="woosc-settings-fields">
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="rfs2" checked /><span class="move">Image</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="3n9d" checked /><span class="move">SKU</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="mea7" checked /><span class="move">Rating</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="4xp9" checked /><span class="move">Price</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="lg34" checked /><span class="move">Stock</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="foug" checked /><span class="move">Availability</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="phjw" checked /><span class="move">Add to cart</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="ot0e" checked /><span class="move">Description</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="ld41" checked /><span class="move">Content</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="h3wx" checked /><span class="move">Weight</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="mvvb" checked /><span class="move">Dimensions</span>
          </li>
          <li class="woosc-settings-field-li">
            <input type="checkbox" class="woosc-settings-field" value="xrdd" checked /><span class="move">Additional information</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<div class="woosc-popup woosc-share">
  <div class="woosc-popup-inner">
    <div class="woosc-popup-content">
      <div class="woosc-popup-content-inner">
        <div class="woosc-popup-close"></div>
        <div class="woosc-share-content"></div>
      </div>
    </div>
  </div>
</div>
<div id="woosc-area" class="woosc-area woosc-bar-bottom woosc-bar-right woosc-bar-click-outside-yes woosc-hide-checkout" data-bg-color="#292a30" data-btn-color="#00a0d2">
  <div class="woosc-inner">
    <div class="woosc-table">
      <div class="woosc-table-inner">
        <a href="#close" id="woosc-table-close" class="woosc-table-close hint--left" aria-label="Close"><span class="woosc-table-close-icon"></span></a>
        <div class="woosc-table-items"></div>
      </div>
    </div>
    <div class="woosc-bar">
      <div class="woosc-bar-notice">
        Click outside to hide the comparison bar
      </div>
      <a href="#print" class="woosc-bar-print hint--top" aria-label="Print"></a>
      <a href="#share" class="woosc-bar-share hint--top" aria-label="Share"></a>
      <a href="#search" class="woosc-bar-search hint--top" aria-label="Add product"></a>
      <div class="woosc-bar-items"></div>
      <div class="woosc-bar-btn woosc-bar-btn-text">
        <div class="woosc-bar-btn-icon-wrapper">
          <div class="woosc-bar-btn-icon-inner">
            <span></span><span></span><span></span>
          </div>
        </div>
        Compare
      </div>
    </div>
  </div>
</div>
<div id="woosw_wishlist" class="woosw-popup woosw-popup-center"></div>
<script type="text/html" id="tmpl-ajax-live-search-template">
  <div class="product-item-search">
    <# if(data.url){ #>
      <a class="product-link" href="{{{data.url}}}" title="{{{data.title}}}">
        <# } #>
          <# if(data.img){#>
          <img src="{{{data.img}}}" alt="{{{data.title}}}" />
          <# } #>
          <div class="product-content">
            <h3 class="product-title">{{{data.title}}}</h3>
            <# if(data.price){ #> {{{data.price}}} <# } #>
          </div>
          <# if(data.url){ #>
        </a>
        <# } #>
      </div>
</script>
<link href="https://fonts.googleapis.com/css?family=Roboto:400%7CPoppins:600%2C700%2C400&amp;display=swap" rel="stylesheet" property="stylesheet" media="all" type="text/css" />
<script type="rocketlazyloadscript" data-rocket-type="text/javascript">
  (function () {
      	var c = document.body.className;
      	c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
      	document.body.className = c;
      })();
    </script>
<div class="site-header-cart-side">
  <div class="cart-side-heading">
    <span class="cart-side-title">Shopping cart</span>
    <a href="#" class="close-cart-side">close</a>
  </div>
  <div class="widget woocommerce widget_shopping_cart">
    <div class="widget_shopping_cart_content"></div>
  </div>
</div>
<div class="cart-side-overlay"></div>
<script type="rocketlazyloadscript">
  if(typeof revslider_showDoubleJqueryError === "undefined") {function revslider_showDoubleJqueryError(sliderID) {console.log("You have some jquery.js library include that comes after the Slider Revolution files js inclusion.");console.log("To fix this, you can:");console.log("1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on");console.log("2. Find the double jQuery.js inclusion and remove it");return "Double Included jQuery Library";}}
    </script>
<link data-minify="1" rel="stylesheet" id="woocommerce-currency-switcher-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce-currency-switcher/css/front787e.css?ver=1714985922" media="all" />
<link data-minify="1" rel="stylesheet" id="elementor-post-5633-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-5633c135.css?ver=1714985931" media="all" />
<link data-minify="1" rel="stylesheet" id="elementor-post-5776-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-5776c135.css?ver=1714985931" media="all" />
<link data-minify="1" rel="stylesheet" id="elementor-post-5775-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-5775c135.css?ver=1714985931" media="all" />
<link data-minify="1" rel="stylesheet" id="elementor-post-5793-css" href="../wp-content/cache/min/1/printec/wp-content/uploads/elementor/css/post-5793c135.css?ver=1714985931" media="all" />
<link rel="stylesheet" id="e-animations-css" href="../wp-content/plugins/elementor/assets/lib/animations/animations.min6319.css?ver=3.15.2" media="all" />
<link data-minify="1" rel="stylesheet" id="rs-plugin-settings-css" href="../wp-content/cache/min/1/printec/wp-content/plugins/revslider/public/assets/css/rs6787e.css?ver=1714985922" media="all" />
<style id="rs-plugin-settings-inline-css">
  #rev_slider_9_1_wrapper .uranus .tp-bullet {
    border-radius: 50%;
    box-shadow: 0 0 0 2px #ffffff;
    -webkit-transition: box-shadow 0.3s ease;
    transition: box-shadow 0.3s ease;
    background: transparent;
    width: 10px;
    height: 10px;
  }

  #rev_slider_9_1_wrapper .uranus .tp-bullet.selected,
  #rev_slider_9_1_wrapper .uranus .tp-bullet.rs-touchhover {
    box-shadow: 0 0 0 2px #ffffff;
    border: none;
    border-radius: 50%;
    background: transparent;
  }

  #rev_slider_9_1_wrapper .uranus .tp-bullet-inner {
    -webkit-transition: background-color 0.3s ease,
      -webkit-transform 0.3s ease;
    transition: background-color 0.3s ease, transform 0.3s ease;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    outline: none;
    border-radius: 50%;
    background-color: #ffffff;
    background-color: #ffffff;
    text-indent: -999em;
    cursor: pointer;
    position: absolute;
  }

  #rev_slider_9_1_wrapper .uranus .tp-bullet.selected .tp-bullet-inner,
  #rev_slider_9_1_wrapper .uranus .tp-bullet.rs-touchhover .tp-bullet-inner {
    transform: scale(0.4);
    -webkit-transform: scale(0.4);
    background-color: #ffffff;
  }
</style>
<script src="../wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script src="../wp-includes/js/jquery/ui/mouse.min3f14.js?ver=1.13.2" id="jquery-ui-mouse-js"></script>
<script src="../wp-includes/js/jquery/ui/resizable.min3f14.js?ver=1.13.2" id="jquery-ui-resizable-js"></script>
<script src="../wp-includes/js/jquery/ui/draggable.min3f14.js?ver=1.13.2" id="jquery-ui-draggable-js"></script>
<script src="../wp-includes/js/jquery/ui/controlgroup.min3f14.js?ver=1.13.2" id="jquery-ui-controlgroup-js"></script>
<script src="../wp-includes/js/jquery/ui/checkboxradio.min3f14.js?ver=1.13.2" id="jquery-ui-checkboxradio-js"></script>
<script src="../wp-includes/js/jquery/ui/button.min3f14.js?ver=1.13.2" id="jquery-ui-button-js"></script>
<script src="../wp-includes/js/jquery/ui/dialog.min3f14.js?ver=1.13.2" id="jquery-ui-dialog-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-includes/js/jquery/jquery.ui.touch-punch787e.js?ver=1714985922" id="jquery-touch-punch-js"></script>
<script src="../wp-includes/js/jquery/ui/sortable.min3f14.js?ver=1.13.2" id="jquery-ui-sortable-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/contact-form-7/includes/swv/js/index787e.js?ver=1714985922" id="swv-js"></script>
<script id="contact-form-7-js-extra">
  var wpcf7 = {
    api: {
      root: "https:\/\/demo2.pavothemes.com\/printec\/wp-json\/",
      namespace: "contact-form-7\/v1",
    },
    cached: "1",
  };
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/contact-form-7/includes/js/index787e.js?ver=1714985922" id="contact-form-7-js"></script>
<script src="../wp-content/plugins/revslider/public/assets/js/rbtools.minf3a0.js?ver=6.6.10" defer async id="tp-tools-js"></script>
<script src="../wp-content/plugins/revslider/public/assets/js/rs6.minf3a0.js?ver=6.6.10" defer async id="revmin-js"></script>
<script src="../wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min144d.js?ver=2.7.0-wc.8.0.2" id="jquery-blockui-js"></script>
<script id="wc-add-to-cart-js-extra">
  var wc_add_to_cart_params = {
    ajax_url: "\/printec\/wp-admin\/admin-ajax.php",
    wc_ajax_url: "\/printec\/?wc-ajax=%%endpoint%%",
    i18n_view_cart: "",
    cart_url: "https:\/\/demo2.pavothemes.com\/printec\/cart\/",
    is_cart: "",
    cart_redirect_after_add: "no",
  };
</script>
<script src="../wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min76d9.js?ver=8.0.2" id="wc-add-to-cart-js"></script>
<script src="../wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min1ff0.js?ver=2.1.4-wc.8.0.2" id="js-cookie-js"></script>
<script id="woocommerce-js-extra">
  var woocommerce_params = {
    ajax_url: "\/printec\/wp-admin\/admin-ajax.php",
    wc_ajax_url: "\/printec\/?wc-ajax=%%endpoint%%",
  };
</script>
<script src="../wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min76d9.js?ver=8.0.2" id="woocommerce-js"></script>
<script src="../wp-content/plugins/drag-and-drop-multiple-file-upload-for-woocommerce/assets/js/codedropz-uploader-minf488.js?ver=1.1.0" id="dndmfu-free-uploader-js"></script>
<script id="dndmfu-wc-free-js-extra">
  var dnd_wc_uploader = {
    ajax_url: "https:\/\/demo2.pavothemes.com\/printec\/wp-admin\/admin-ajax.php",
    nonce: "b0aee1f56c",
    drag_n_drop_upload: {
      text: "Drag & Drop Files Here",
      or_separator: "or",
      browse: "Browse Files",
      server_max_error: "The uploaded file exceeds the maximum upload size of your server.",
      large_file: "Uploaded file is too large",
      inavalid_type: "Uploaded file is not allowed for file type",
      minimum_file: "Please upload atleast %s file(s).",
      maxNumFiles: "You have reached the maximum number of files ( Only %s files allowed )",
      maxFileLimit: "Note : Some of the files could not be uploaded ( Only %s files allowed )",
    },
    uploader_text: {
      of: "of",
      delete: "Deleting...",
      remove: "Remove"
    },
  };
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/drag-and-drop-multiple-file-upload-for-woocommerce/assets/js/dnd-upload-wc787e.js?ver=1714985922" id="dndmfu-wc-free-js"></script>
<script src="../wp-includes/js/underscore.mind584.js?ver=1.13.4" id="underscore-js"></script>
<script id="wp-util-js-extra">
  var _wpUtilSettings = {
    ajax: {
      url: "\/printec\/wp-admin\/admin-ajax.php"
    },
  };
</script>
<script src="../wp-includes/js/wp-util.minadc6.js?ver=6.5.5" id="wp-util-js"></script>
<script id="wp-api-request-js-extra">
  var wpApiSettings = {
    root: "https:\/\/demo2.pavothemes.com\/printec\/wp-json\/",
    nonce: "7217c15339",
    versionString: "wp\/v2\/",
  };
</script>
<script src="../wp-includes/js/api-request.minadc6.js?ver=6.5.5" id="wp-api-request-js"></script>
<script src="../wp-includes/js/dist/vendor/wp-polyfill-inert.min0226.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script src="../wp-includes/js/dist/vendor/regenerator-runtime.min6c85.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script src="../wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script src="../wp-includes/js/dist/hooks.min2757.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
<script src="../wp-includes/js/dist/i18n.minc33c.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
  wp.i18n.setLocaleData({
    "text direction\u0004ltr": ["ltr"]
  });
</script>
<script src="../wp-includes/js/dist/url.min253b.js?ver=421139b01f33e5b327d8" id="wp-url-js"></script>
<script src="../wp-includes/js/dist/api-fetch.min803c.js?ver=4c185334c5ec26e149cc" id="wp-api-fetch-js"></script>
<script id="wp-api-fetch-js-after">
  wp.apiFetch.use(
    wp.apiFetch.createRootURLMiddleware(
      "https://demo2.pavothemes.com/printec/wp-json/"
    )
  );
  wp.apiFetch.nonceMiddleware =
    wp.apiFetch.createNonceMiddleware("7217c15339");
  wp.apiFetch.use(wp.apiFetch.nonceMiddleware);
  wp.apiFetch.use(wp.apiFetch.mediaUploadMiddleware);
  wp.apiFetch.nonceEndpoint =
    "https://demo2.pavothemes.com/printec/wp-admin/admin-ajax.php?action=rest-nonce";
</script>
<script id="woo-variation-swatches-js-extra">
  var woo_variation_swatches_options = {
    show_variation_label: "",
    clear_on_reselect: "",
    variation_label_separator: ":",
    is_mobile: "",
    show_variation_stock: "",
    stock_label_threshold: "5",
    cart_redirect_after_add: "no",
    enable_ajax_add_to_cart: "yes",
    cart_url: "https:\/\/demo2.pavothemes.com\/printec\/cart\/",
    is_cart: "",
  };
</script>
<script src="../wp-content/plugins/woo-variation-swatches/assets/js/frontend.min177b.js?ver=1688434790" id="woo-variation-swatches-js"></script>
<script id="rocket-browser-checker-js-after">
  "use strict";
  var _createClass = (function() {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        (descriptor.enumerable = descriptor.enumerable || !1),
        (descriptor.configurable = !0),
        "value" in descriptor && (descriptor.writable = !0),
          Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    return function(Constructor, protoProps, staticProps) {
      return (
        protoProps && defineProperties(Constructor.prototype, protoProps),
        staticProps && defineProperties(Constructor, staticProps),
        Constructor
      );
    };
  })();

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor))
      throw new TypeError("Cannot call a class as a function");
  }
  var RocketBrowserCompatibilityChecker = (function() {
    function RocketBrowserCompatibilityChecker(options) {
      _classCallCheck(this, RocketBrowserCompatibilityChecker),
        (this.passiveSupported = !1),
        this._checkPassiveOption(this),
        (this.options = !!this.passiveSupported && options);
    }
    return (
      _createClass(RocketBrowserCompatibilityChecker, [{
          key: "_checkPassiveOption",
          value: function(self) {
            try {
              var options = {
                get passive() {
                  return !(self.passiveSupported = !0);
                },
              };
              window.addEventListener("test", null, options),
                window.removeEventListener("test", null, options);
            } catch (err) {
              self.passiveSupported = !1;
            }
          },
        },
        {
          key: "initRequestIdleCallback",
          value: function() {
            !1 in window &&
              (window.requestIdleCallback = function(cb) {
                var start = Date.now();
                return setTimeout(function() {
                  cb({
                    didTimeout: !1,
                    timeRemaining: function() {
                      return Math.max(0, 50 - (Date.now() - start));
                    },
                  });
                }, 1);
              }),
              !1 in window &&
              (window.cancelIdleCallback = function(id) {
                return clearTimeout(id);
              });
          },
        },
        {
          key: "isDataSaverModeOn",
          value: function() {
            return (
              "connection" in navigator &&
              !0 === navigator.connection.saveData
            );
          },
        },
        {
          key: "supportsLinkPrefetch",
          value: function() {
            var elem = document.createElement("link");
            return (
              elem.relList &&
              elem.relList.supports &&
              elem.relList.supports("prefetch") &&
              window.IntersectionObserver &&
              "isIntersecting" in IntersectionObserverEntry.prototype
            );
          },
        },
        {
          key: "isSlowConnection",
          value: function() {
            return (
              "connection" in navigator &&
              "effectiveType" in navigator.connection &&
              ("2g" === navigator.connection.effectiveType ||
                "slow-2g" === navigator.connection.effectiveType)
            );
          },
        },
      ]),
      RocketBrowserCompatibilityChecker
    );
  })();
</script>
<script id="rocket-preload-links-js-extra">
  var RocketPreloadLinksConfig = {
    excludeUris: "\/printec(\/(.+\/)?feed\/?.+\/?|\/(?:.+\/)?embed\/|\/checkout\/|\/cart\/|\/my-account\/|\/wc-api\/v(.*)|\/(index\\.php\/)?wp\\-json(\/.*|$))|\/wp-admin\/|\/logout\/|\/wp-login.php",
    usesTrailingSlash: "1",
    imageExt: "jpg|jpeg|gif|png|tiff|bmp|webp|avif",
    fileExt: "jpg|jpeg|gif|png|tiff|bmp|webp|avif|php|pdf|html|htm",
    siteUrl: "https:\/\/demo2.pavothemes.com\/printec",
    onHoverDelay: "100",
    rateThrottle: "3",
  };
</script>
<script id="rocket-preload-links-js-after">
  (function() {
    "use strict";
    var r =
      "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
      function(e) {
        return typeof e;
      } :
      function(e) {
        return e &&
          "function" == typeof Symbol &&
          e.constructor === Symbol &&
          e !== Symbol.prototype ?
          "symbol" :
          typeof e;
      },
      e = (function() {
        function i(e, t) {
          for (var n = 0; n < t.length; n++) {
            var i = t[n];
            (i.enumerable = i.enumerable || !1),
            (i.configurable = !0),
            "value" in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        return function(e, t, n) {
          return t && i(e.prototype, t), n && i(e, n), e;
        };
      })();

    function i(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    var t = (function() {
      function n(e, t) {
        i(this, n),
          (this.browser = e),
          (this.config = t),
          (this.options = this.browser.options),
          (this.prefetched = new Set()),
          (this.eventTime = null),
          (this.threshold = 1111),
          (this.numOnHover = 0);
      }
      return (
        e(
          n,
          [{
              key: "init",
              value: function() {
                !this.browser.supportsLinkPrefetch() ||
                  this.browser.isDataSaverModeOn() ||
                  this.browser.isSlowConnection() ||
                  ((this.regex = {
                      excludeUris: RegExp(this.config.excludeUris, "i"),
                      images: RegExp(".(" + this.config.imageExt + ")$", "i"),
                      fileExt: RegExp(".(" + this.config.fileExt + ")$", "i"),
                    }),
                    this._initListeners(this));
              },
            },
            {
              key: "_initListeners",
              value: function(e) {
                -1 < this.config.onHoverDelay &&
                  document.addEventListener(
                    "mouseover",
                    e.listener.bind(e),
                    e.listenerOptions
                  ),
                  document.addEventListener(
                    "mousedown",
                    e.listener.bind(e),
                    e.listenerOptions
                  ),
                  document.addEventListener(
                    "touchstart",
                    e.listener.bind(e),
                    e.listenerOptions
                  );
              },
            },
            {
              key: "listener",
              value: function(e) {
                var t = e.target.closest("a"),
                  n = this._prepareUrl(t);
                if (null !== n)
                  switch (e.type) {
                    case "mousedown":
                    case "touchstart":
                      this._addPrefetchLink(n);
                      break;
                    case "mouseover":
                      this._earlyPrefetch(t, n, "mouseout");
                  }
              },
            },
            {
              key: "_earlyPrefetch",
              value: function(t, e, n) {
                var i = this,
                  r = setTimeout(function() {
                    if (((r = null), 0 === i.numOnHover))
                      setTimeout(function() {
                        return (i.numOnHover = 0);
                      }, 1e3);
                    else if (i.numOnHover > i.config.rateThrottle) return;
                    i.numOnHover++, i._addPrefetchLink(e);
                  }, this.config.onHoverDelay);
                t.addEventListener(
                  n,
                  function e() {
                    t.removeEventListener(n, e, {
                        passive: !0
                      }),
                      null !== r && (clearTimeout(r), (r = null));
                  }, {
                    passive: !0
                  }
                );
              },
            },
            {
              key: "_addPrefetchLink",
              value: function(i) {
                return (
                  this.prefetched.add(i.href),
                  new Promise(function(e, t) {
                    var n = document.createElement("link");
                    (n.rel = "prefetch"),
                    (n.href = i.href),
                    (n.onload = e),
                    (n.onerror = t),
                    document.head.appendChild(n);
                  }).catch(function() {})
                );
              },
            },
            {
              key: "_prepareUrl",
              value: function(e) {
                if (
                  null === e ||
                  "object" !== (void 0 === e ? "undefined" : r(e)) ||
                  !1 in e ||
                  -1 === ["http:", "https:"].indexOf(e.protocol)
                )
                  return null;
                var t = e.href.substring(0, this.config.siteUrl.length),
                  n = this._getPathname(e.href, t),
                  i = {
                    original: e.href,
                    protocol: e.protocol,
                    origin: t,
                    pathname: n,
                    href: t + n,
                  };
                return this._isLinkOk(i) ? i : null;
              },
            },
            {
              key: "_getPathname",
              value: function(e, t) {
                var n = t ? e.substring(this.config.siteUrl.length) : e;
                return (
                  n.startsWith("https://demo2.pavothemes.com/") ||
                  (n = "/" + n),
                  this._shouldAddTrailingSlash(n) ? n + "/" : n
                );
              },
            },
            {
              key: "_shouldAddTrailingSlash",
              value: function(e) {
                return (
                  this.config.usesTrailingSlash &&
                  !e.endsWith("https://demo2.pavothemes.com/") &&
                  !this.regex.fileExt.test(e)
                );
              },
            },
            {
              key: "_isLinkOk",
              value: function(e) {
                return (
                  null !== e &&
                  "object" === (void 0 === e ? "undefined" : r(e)) &&
                  !this.prefetched.has(e.href) &&
                  e.origin === this.config.siteUrl &&
                  -1 === e.href.indexOf("?") &&
                  -1 === e.href.indexOf("#") &&
                  !this.regex.excludeUris.test(e.href) &&
                  !this.regex.images.test(e.href)
                );
              },
            },
          ],
          [{
            key: "run",
            value: function() {
              "undefined" != typeof RocketPreloadLinksConfig &&
                new n(
                  new RocketBrowserCompatibilityChecker({
                    capture: !0,
                    passive: !0,
                  }),
                  RocketPreloadLinksConfig
                ).init();
            },
          }, ]
        ),
        n
      );
    })();
    t.run();
  })();
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-compare/assets/libs/print/jQuery.print787e.js?ver=1714985922" id="print-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-compare/assets/libs/table-head-fixer/table-head-fixer787e.js?ver=1714985922" id="table-head-fixer-js"></script>
<script src="../wp-content/plugins/woo-smart-compare/assets/libs/perfect-scrollbar/js/perfect-scrollbar.jquery.min6a4d.js?ver=6.1.1" id="perfect-scrollbar-js"></script>
<script id="woosc-frontend-js-extra">
  var woosc_vars = {
    ajax_url: "https:\/\/demo2.pavothemes.com\/printec\/wp-admin\/admin-ajax.php",
    nonce: "8afdb45e51",
    hash: "6",
    user_id: "0cdb64fab32a05bd393b20c8c351de9f",
    page_url: "#",
    open_button: "",
    open_button_action: "open_popup",
    menu_action: "open_popup",
    button_action: "show_table",
    sidebar_position: "right",
    message_position: "right-top",
    message_added: "{name} has been added to Compare list.",
    message_removed: "{name} has been removed from the Compare list.",
    message_exists: "{name} is already in the Compare list.",
    open_bar: "no",
    bar_bubble: "no",
    adding: "prepend",
    click_again: "no",
    hide_empty: "no",
    click_outside: "yes",
    freeze_column: "yes",
    freeze_row: "yes",
    scrollbar: "yes",
    limit: "100",
    remove_all: "Do you want to remove all products from the compare?",
    limit_notice: "You can add a maximum of {limit} products to the comparison table.",
    copied_text: "Share link %s was copied to clipboard!",
    button_text: "Compare",
    button_text_added: "Compare",
    button_normal_icon: "woosc-icon-1",
    button_added_icon: "woosc-icon-74",
  };
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-compare/assets/js/frontend787e.js?ver=1714985922" id="woosc-frontend-js"></script>
<script id="wc-add-to-cart-variation-js-extra">
  var wc_add_to_cart_variation_params = {
    wc_ajax_url: "\/printec\/?wc-ajax=%%endpoint%%",
    i18n_no_matching_variations_text: "Sorry, no products matched your selection. Please choose a different combination.",
    i18n_make_a_selection_text: "Please select some product options before adding this product to your cart.",
    i18n_unavailable_text: "Sorry, this product is unavailable. Please choose a different combination.",
  };
</script>
<script src="../wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min76d9.js?ver=8.0.2" id="wc-add-to-cart-variation-js"></script>
<script src="../wp-content/themes/printec/assets/js/vendor/slick.min1576.js?ver=1.2.1" id="slick-js"></script>
<script src="../wp-content/themes/printec/assets/js/vendor/jquery.magnific-popup.min1576.js?ver=1.2.1" id="magnific-popup-js"></script>
<script id="woosq-frontend-js-extra">
  var woosq_vars = {
    ajax_url: "https:\/\/demo2.pavothemes.com\/printec\/wp-admin\/admin-ajax.php",
    nonce: "931b773dfc",
    view: "popup",
    effect: "mfp-3d-unfold",
    scrollbar: "yes",
    auto_close: "yes",
    hashchange: "no",
    cart_redirect: "no",
    cart_url: "https:\/\/demo2.pavothemes.com\/printec\/cart\/",
    close: "Close (Esc)",
    next: "Next (Right arrow key)",
    prev: "Previous (Left arrow key)",
    thumbnails_effect: "no",
    related_slick_params: '{"slidesToShow":2,"slidesToScroll":2,"dots":true,"arrows":false,"adaptiveHeight":true,"rtl":false}',
    thumbnails_slick_params: '{"slidesToShow":1,"slidesToScroll":1,"dots":true,"arrows":true,"adaptiveHeight":false,"rtl":false}',
    thumbnails_zoom_params: '{"duration":120,"magnify":1}',
    quick_view: "0",
  };
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-quick-view/assets/js/frontend787e.js?ver=1714985922" id="woosq-frontend-js"></script>
<script id="woosw-frontend-js-extra">
  var woosw_vars = {
    ajax_url: "https:\/\/demo2.pavothemes.com\/printec\/wp-admin\/admin-ajax.php",
    nonce: "e62e021f32",
    menu_action: "open_page",
    perfect_scrollbar: "yes",
    wishlist_url: "https:\/\/demo2.pavothemes.com\/printec\/wishlist\/",
    button_action: "list",
    message_position: "right-top",
    button_action_added: "popup",
    empty_confirm: "This action cannot be undone. Are you sure?",
    delete_confirm: "This action cannot be undone. Are you sure?",
    copied_text: "Copied the wishlist link:",
    menu_text: "Wishlist",
    button_text: "Add to wishlist",
    button_text_added: "Browse wishlist",
    button_normal_icon: "woosw-icon-5",
    button_added_icon: "woosw-icon-8",
    button_loading_icon: "woosw-icon-4",
  };
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woo-smart-wishlist/assets/js/frontend787e.js?ver=1714985922" id="woosw-frontend-js"></script>
<script id="printec-theme-js-extra">
  var printecAjax = {
    ajaxurl: "https:\/\/demo2.pavothemes.com\/printec\/wp-admin\/admin-ajax.php",
  };
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/frontend/main787e.js?ver=1714985922" id="printec-theme-js"></script>
<script src="../wp-includes/js/imagesloaded.minbb93.js?ver=5.0.0" id="imagesloaded-js"></script>
<script src="../wp-content/themes/printec/assets/js/skip-link-focus-fix.min08e0.js?ver=20130115" id="printec-skip-link-focus-fix-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/frontend/search-popup787e.js?ver=1714985922" id="printec-search-popup-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/frontend/text-editor787e.js?ver=1714985922" id="printec-text-editor-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/frontend/nav-mobile787e.js?ver=1714985922" id="printec-nav-mobile-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/inc/megamenu/assets/js/frontend787e.js?ver=1714985922" id="printec-megamenu-frontend-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/frontend/login787e.js?ver=1714985922" id="printec-ajax-login-js"></script>
<script src="../wp-content/themes/printec/assets/js/woocommerce/header-cart.min1576.js?ver=1.2.1" id="printec-header-cart-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/tooltipster.bundle787e.js?ver=1714985922" id="tooltipster-js"></script>
<script src="../wp-content/themes/printec/assets/js/woocommerce/shop-select.min1576.js?ver=1.2.1" id="printec-shop-select-js"></script>
<script src="../wp-content/themes/printec/assets/js/woocommerce/product-ajax-search.min1576.js?ver=1.2.1" id="printec-products-ajax-search-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/vendor/waypoints787e.js?ver=1714985922" id="printec-waypoints-js"></script>
<script src="../wp-content/themes/printec/assets/js/woocommerce/main.min1576.js?ver=1.2.1" id="printec-products-js"></script>
<script src="../wp-content/themes/printec/assets/js/woocommerce/quantity.min1576.js?ver=1.2.1" id="printec-input-quantity-js"></script>
<script src="../wp-content/themes/printec/assets/js/woocommerce/off-canvas.min1576.js?ver=1.2.1" id="printec-off-canvas-js"></script>
<script src="../wp-content/themes/printec/assets/js/woocommerce/cart-canvas.min1576.js?ver=1.2.1" id="printec-cart-canvas-js"></script>
<script src="../wp-includes/js/jquery/ui/slider.min3f14.js?ver=1.13.2" id="jquery-ui-slider-js"></script>
<script src="../wp-content/plugins/woocommerce/assets/js/jquery-ui-touch-punch/jquery-ui-touch-punch.min76d9.js?ver=8.0.2" id="wc-jquery-ui-touchpunch-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce-currency-switcher/js/price-slider_33787e.js?ver=1714985922" id="wc-price-slider_33-js"></script>
<script id="wc-settings-js-before">
  var wcSettings =
    wcSettings ||
    JSON.parse(
      decodeURIComponent(
        "%7B%22shippingCostRequiresAddress%22%3Afalse%2C%22adminUrl%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fwp-admin%5C%2F%22%2C%22countries%22%3A%7B%22AF%22%3A%22Afghanistan%22%2C%22AX%22%3A%22%5Cu00c5land%20Islands%22%2C%22AL%22%3A%22Albania%22%2C%22DZ%22%3A%22Algeria%22%2C%22AS%22%3A%22American%20Samoa%22%2C%22AD%22%3A%22Andorra%22%2C%22AO%22%3A%22Angola%22%2C%22AI%22%3A%22Anguilla%22%2C%22AQ%22%3A%22Antarctica%22%2C%22AG%22%3A%22Antigua%20and%20Barbuda%22%2C%22AR%22%3A%22Argentina%22%2C%22AM%22%3A%22Armenia%22%2C%22AW%22%3A%22Aruba%22%2C%22AU%22%3A%22Australia%22%2C%22AT%22%3A%22Austria%22%2C%22AZ%22%3A%22Azerbaijan%22%2C%22BS%22%3A%22Bahamas%22%2C%22BH%22%3A%22Bahrain%22%2C%22BD%22%3A%22Bangladesh%22%2C%22BB%22%3A%22Barbados%22%2C%22BY%22%3A%22Belarus%22%2C%22PW%22%3A%22Belau%22%2C%22BE%22%3A%22Belgium%22%2C%22BZ%22%3A%22Belize%22%2C%22BJ%22%3A%22Benin%22%2C%22BM%22%3A%22Bermuda%22%2C%22BT%22%3A%22Bhutan%22%2C%22BO%22%3A%22Bolivia%22%2C%22BQ%22%3A%22Bonaire%2C%20Saint%20Eustatius%20and%20Saba%22%2C%22BA%22%3A%22Bosnia%20and%20Herzegovina%22%2C%22BW%22%3A%22Botswana%22%2C%22BV%22%3A%22Bouvet%20Island%22%2C%22BR%22%3A%22Brazil%22%2C%22IO%22%3A%22British%20Indian%20Ocean%20Territory%22%2C%22BN%22%3A%22Brunei%22%2C%22BG%22%3A%22Bulgaria%22%2C%22BF%22%3A%22Burkina%20Faso%22%2C%22BI%22%3A%22Burundi%22%2C%22KH%22%3A%22Cambodia%22%2C%22CM%22%3A%22Cameroon%22%2C%22CA%22%3A%22Canada%22%2C%22CV%22%3A%22Cape%20Verde%22%2C%22KY%22%3A%22Cayman%20Islands%22%2C%22CF%22%3A%22Central%20African%20Republic%22%2C%22TD%22%3A%22Chad%22%2C%22CL%22%3A%22Chile%22%2C%22CN%22%3A%22China%22%2C%22CX%22%3A%22Christmas%20Island%22%2C%22CC%22%3A%22Cocos%20%28Keeling%29%20Islands%22%2C%22CO%22%3A%22Colombia%22%2C%22KM%22%3A%22Comoros%22%2C%22CG%22%3A%22Congo%20%28Brazzaville%29%22%2C%22CD%22%3A%22Congo%20%28Kinshasa%29%22%2C%22CK%22%3A%22Cook%20Islands%22%2C%22CR%22%3A%22Costa%20Rica%22%2C%22HR%22%3A%22Croatia%22%2C%22CU%22%3A%22Cuba%22%2C%22CW%22%3A%22Cura%26ccedil%3Bao%22%2C%22CY%22%3A%22Cyprus%22%2C%22CZ%22%3A%22Czech%20Republic%22%2C%22DK%22%3A%22Denmark%22%2C%22DJ%22%3A%22Djibouti%22%2C%22DM%22%3A%22Dominica%22%2C%22DO%22%3A%22Dominican%20Republic%22%2C%22EC%22%3A%22Ecuador%22%2C%22EG%22%3A%22Egypt%22%2C%22SV%22%3A%22El%20Salvador%22%2C%22GQ%22%3A%22Equatorial%20Guinea%22%2C%22ER%22%3A%22Eritrea%22%2C%22EE%22%3A%22Estonia%22%2C%22SZ%22%3A%22Eswatini%22%2C%22ET%22%3A%22Ethiopia%22%2C%22FK%22%3A%22Falkland%20Islands%22%2C%22FO%22%3A%22Faroe%20Islands%22%2C%22FJ%22%3A%22Fiji%22%2C%22FI%22%3A%22Finland%22%2C%22FR%22%3A%22France%22%2C%22GF%22%3A%22French%20Guiana%22%2C%22PF%22%3A%22French%20Polynesia%22%2C%22TF%22%3A%22French%20Southern%20Territories%22%2C%22GA%22%3A%22Gabon%22%2C%22GM%22%3A%22Gambia%22%2C%22GE%22%3A%22Georgia%22%2C%22DE%22%3A%22Germany%22%2C%22GH%22%3A%22Ghana%22%2C%22GI%22%3A%22Gibraltar%22%2C%22GR%22%3A%22Greece%22%2C%22GL%22%3A%22Greenland%22%2C%22GD%22%3A%22Grenada%22%2C%22GP%22%3A%22Guadeloupe%22%2C%22GU%22%3A%22Guam%22%2C%22GT%22%3A%22Guatemala%22%2C%22GG%22%3A%22Guernsey%22%2C%22GN%22%3A%22Guinea%22%2C%22GW%22%3A%22Guinea-Bissau%22%2C%22GY%22%3A%22Guyana%22%2C%22HT%22%3A%22Haiti%22%2C%22HM%22%3A%22Heard%20Island%20and%20McDonald%20Islands%22%2C%22HN%22%3A%22Honduras%22%2C%22HK%22%3A%22Hong%20Kong%22%2C%22HU%22%3A%22Hungary%22%2C%22IS%22%3A%22Iceland%22%2C%22IN%22%3A%22India%22%2C%22ID%22%3A%22Indonesia%22%2C%22IR%22%3A%22Iran%22%2C%22IQ%22%3A%22Iraq%22%2C%22IE%22%3A%22Ireland%22%2C%22IM%22%3A%22Isle%20of%20Man%22%2C%22IL%22%3A%22Israel%22%2C%22IT%22%3A%22Italy%22%2C%22CI%22%3A%22Ivory%20Coast%22%2C%22JM%22%3A%22Jamaica%22%2C%22JP%22%3A%22Japan%22%2C%22JE%22%3A%22Jersey%22%2C%22JO%22%3A%22Jordan%22%2C%22KZ%22%3A%22Kazakhstan%22%2C%22KE%22%3A%22Kenya%22%2C%22KI%22%3A%22Kiribati%22%2C%22KW%22%3A%22Kuwait%22%2C%22KG%22%3A%22Kyrgyzstan%22%2C%22LA%22%3A%22Laos%22%2C%22LV%22%3A%22Latvia%22%2C%22LB%22%3A%22Lebanon%22%2C%22LS%22%3A%22Lesotho%22%2C%22LR%22%3A%22Liberia%22%2C%22LY%22%3A%22Libya%22%2C%22LI%22%3A%22Liechtenstein%22%2C%22LT%22%3A%22Lithuania%22%2C%22LU%22%3A%22Luxembourg%22%2C%22MO%22%3A%22Macao%22%2C%22MG%22%3A%22Madagascar%22%2C%22MW%22%3A%22Malawi%22%2C%22MY%22%3A%22Malaysia%22%2C%22MV%22%3A%22Maldives%22%2C%22ML%22%3A%22Mali%22%2C%22MT%22%3A%22Malta%22%2C%22MH%22%3A%22Marshall%20Islands%22%2C%22MQ%22%3A%22Martinique%22%2C%22MR%22%3A%22Mauritania%22%2C%22MU%22%3A%22Mauritius%22%2C%22YT%22%3A%22Mayotte%22%2C%22MX%22%3A%22Mexico%22%2C%22FM%22%3A%22Micronesia%22%2C%22MD%22%3A%22Moldova%22%2C%22MC%22%3A%22Monaco%22%2C%22MN%22%3A%22Mongolia%22%2C%22ME%22%3A%22Montenegro%22%2C%22MS%22%3A%22Montserrat%22%2C%22MA%22%3A%22Morocco%22%2C%22MZ%22%3A%22Mozambique%22%2C%22MM%22%3A%22Myanmar%22%2C%22NA%22%3A%22Namibia%22%2C%22NR%22%3A%22Nauru%22%2C%22NP%22%3A%22Nepal%22%2C%22NL%22%3A%22Netherlands%22%2C%22NC%22%3A%22New%20Caledonia%22%2C%22NZ%22%3A%22New%20Zealand%22%2C%22NI%22%3A%22Nicaragua%22%2C%22NE%22%3A%22Niger%22%2C%22NG%22%3A%22Nigeria%22%2C%22NU%22%3A%22Niue%22%2C%22NF%22%3A%22Norfolk%20Island%22%2C%22KP%22%3A%22North%20Korea%22%2C%22MK%22%3A%22North%20Macedonia%22%2C%22MP%22%3A%22Northern%20Mariana%20Islands%22%2C%22NO%22%3A%22Norway%22%2C%22OM%22%3A%22Oman%22%2C%22PK%22%3A%22Pakistan%22%2C%22PS%22%3A%22Palestinian%20Territory%22%2C%22PA%22%3A%22Panama%22%2C%22PG%22%3A%22Papua%20New%20Guinea%22%2C%22PY%22%3A%22Paraguay%22%2C%22PE%22%3A%22Peru%22%2C%22PH%22%3A%22Philippines%22%2C%22PN%22%3A%22Pitcairn%22%2C%22PL%22%3A%22Poland%22%2C%22PT%22%3A%22Portugal%22%2C%22PR%22%3A%22Puerto%20Rico%22%2C%22QA%22%3A%22Qatar%22%2C%22RE%22%3A%22Reunion%22%2C%22RO%22%3A%22Romania%22%2C%22RU%22%3A%22Russia%22%2C%22RW%22%3A%22Rwanda%22%2C%22ST%22%3A%22S%26atilde%3Bo%20Tom%26eacute%3B%20and%20Pr%26iacute%3Bncipe%22%2C%22BL%22%3A%22Saint%20Barth%26eacute%3Blemy%22%2C%22SH%22%3A%22Saint%20Helena%22%2C%22KN%22%3A%22Saint%20Kitts%20and%20Nevis%22%2C%22LC%22%3A%22Saint%20Lucia%22%2C%22SX%22%3A%22Saint%20Martin%20%28Dutch%20part%29%22%2C%22MF%22%3A%22Saint%20Martin%20%28French%20part%29%22%2C%22PM%22%3A%22Saint%20Pierre%20and%20Miquelon%22%2C%22VC%22%3A%22Saint%20Vincent%20and%20the%20Grenadines%22%2C%22WS%22%3A%22Samoa%22%2C%22SM%22%3A%22San%20Marino%22%2C%22SA%22%3A%22Saudi%20Arabia%22%2C%22SN%22%3A%22Senegal%22%2C%22RS%22%3A%22Serbia%22%2C%22SC%22%3A%22Seychelles%22%2C%22SL%22%3A%22Sierra%20Leone%22%2C%22SG%22%3A%22Singapore%22%2C%22SK%22%3A%22Slovakia%22%2C%22SI%22%3A%22Slovenia%22%2C%22SB%22%3A%22Solomon%20Islands%22%2C%22SO%22%3A%22Somalia%22%2C%22ZA%22%3A%22South%20Africa%22%2C%22GS%22%3A%22South%20Georgia%5C%2FSandwich%20Islands%22%2C%22KR%22%3A%22South%20Korea%22%2C%22SS%22%3A%22South%20Sudan%22%2C%22ES%22%3A%22Spain%22%2C%22LK%22%3A%22Sri%20Lanka%22%2C%22SD%22%3A%22Sudan%22%2C%22SR%22%3A%22Suriname%22%2C%22SJ%22%3A%22Svalbard%20and%20Jan%20Mayen%22%2C%22SE%22%3A%22Sweden%22%2C%22CH%22%3A%22Switzerland%22%2C%22SY%22%3A%22Syria%22%2C%22TW%22%3A%22Taiwan%22%2C%22TJ%22%3A%22Tajikistan%22%2C%22TZ%22%3A%22Tanzania%22%2C%22TH%22%3A%22Thailand%22%2C%22TL%22%3A%22Timor-Leste%22%2C%22TG%22%3A%22Togo%22%2C%22TK%22%3A%22Tokelau%22%2C%22TO%22%3A%22Tonga%22%2C%22TT%22%3A%22Trinidad%20and%20Tobago%22%2C%22TN%22%3A%22Tunisia%22%2C%22TR%22%3A%22Turkey%22%2C%22TM%22%3A%22Turkmenistan%22%2C%22TC%22%3A%22Turks%20and%20Caicos%20Islands%22%2C%22TV%22%3A%22Tuvalu%22%2C%22UG%22%3A%22Uganda%22%2C%22UA%22%3A%22Ukraine%22%2C%22AE%22%3A%22United%20Arab%20Emirates%22%2C%22GB%22%3A%22United%20Kingdom%20%28UK%29%22%2C%22US%22%3A%22United%20States%20%28US%29%22%2C%22UM%22%3A%22United%20States%20%28US%29%20Minor%20Outlying%20Islands%22%2C%22UY%22%3A%22Uruguay%22%2C%22UZ%22%3A%22Uzbekistan%22%2C%22VU%22%3A%22Vanuatu%22%2C%22VA%22%3A%22Vatican%22%2C%22VE%22%3A%22Venezuela%22%2C%22VN%22%3A%22Vietnam%22%2C%22VG%22%3A%22Virgin%20Islands%20%28British%29%22%2C%22VI%22%3A%22Virgin%20Islands%20%28US%29%22%2C%22WF%22%3A%22Wallis%20and%20Futuna%22%2C%22EH%22%3A%22Western%20Sahara%22%2C%22YE%22%3A%22Yemen%22%2C%22ZM%22%3A%22Zambia%22%2C%22ZW%22%3A%22Zimbabwe%22%7D%2C%22currency%22%3A%7B%22code%22%3A%22USD%22%2C%22precision%22%3A2%2C%22symbol%22%3A%22%24%22%2C%22symbolPosition%22%3A%22left%22%2C%22decimalSeparator%22%3A%22.%22%2C%22thousandSeparator%22%3A%22%2C%22%2C%22priceFormat%22%3A%22%251%24s%252%24s%22%7D%2C%22currentUserId%22%3A0%2C%22currentUserIsAdmin%22%3Afalse%2C%22homeUrl%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2F%22%2C%22locale%22%3A%7B%22siteLocale%22%3A%22en_US%22%2C%22userLocale%22%3A%22en_US%22%2C%22weekdaysShort%22%3A%5B%22Sun%22%2C%22Mon%22%2C%22Tue%22%2C%22Wed%22%2C%22Thu%22%2C%22Fri%22%2C%22Sat%22%5D%7D%2C%22dashboardUrl%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fmy-account%5C%2F%22%2C%22orderStatuses%22%3A%7B%22pending%22%3A%22Pending%20payment%22%2C%22processing%22%3A%22Processing%22%2C%22on-hold%22%3A%22On%20hold%22%2C%22completed%22%3A%22Completed%22%2C%22cancelled%22%3A%22Cancelled%22%2C%22refunded%22%3A%22Refunded%22%2C%22failed%22%3A%22Failed%22%2C%22checkout-draft%22%3A%22Draft%22%7D%2C%22placeholderImgSrc%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fwp-content%5C%2Fuploads%5C%2Fwoocommerce-placeholder-600x600.png%22%2C%22productsSettings%22%3A%7B%22cartRedirectAfterAdd%22%3Afalse%7D%2C%22siteTitle%22%3A%22Printec%22%2C%22storePages%22%3A%7B%22myaccount%22%3A%7B%22id%22%3A16%2C%22title%22%3A%22My%20account%22%2C%22permalink%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fmy-account%5C%2F%22%7D%2C%22shop%22%3A%7B%22id%22%3A13%2C%22title%22%3A%22Shop%22%2C%22permalink%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fshop%5C%2F%22%7D%2C%22cart%22%3A%7B%22id%22%3A14%2C%22title%22%3A%22Cart%22%2C%22permalink%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fcart%5C%2F%22%7D%2C%22checkout%22%3A%7B%22id%22%3A15%2C%22title%22%3A%22Checkout%22%2C%22permalink%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fcheckout%5C%2F%22%7D%2C%22privacy%22%3A%7B%22id%22%3A0%2C%22title%22%3A%22%22%2C%22permalink%22%3Afalse%7D%2C%22terms%22%3A%7B%22id%22%3A0%2C%22title%22%3A%22%22%2C%22permalink%22%3Afalse%7D%7D%2C%22wcAssetUrl%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fwp-content%5C%2Fplugins%5C%2Fwoocommerce%5C%2Fassets%5C%2F%22%2C%22wcVersion%22%3A%228.0.2%22%2C%22wpLoginUrl%22%3A%22https%3A%5C%2F%5C%2Fdemo2.pavothemes.com%5C%2Fprintec%5C%2Fwp-login.php%22%2C%22wpVersion%22%3A%226.5.5%22%2C%22collectableMethodIds%22%3A%5B%5D%2C%22admin%22%3A%7B%22_feature_nonce%22%3A%229ca601d2cb%22%2C%22alertCount%22%3A%220%22%2C%22visibleTaskListIds%22%3A%5B%22setup%22%2C%22extended%22%5D%7D%7D"
      )
    );
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-settings787e.js?ver=1714985922" id="wc-settings-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-format787e.js?ver=1714985922" id="wc-price-format-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce-currency-switcher/js/priceformat787e.js?ver=1714985922" id="wc-priceformat-js"></script>
<script src="../wp-includes/js/dist/vendor/react.min7a3b.js?ver=18.2.0" id="react-js"></script>
<script src="../wp-includes/js/dist/deprecated.min0a8b.js?ver=e1f84915c5e8ae38964c" id="wp-deprecated-js"></script>
<script src="../wp-includes/js/dist/dom.mindad4.js?ver=4ecffbffba91b10c5c7a" id="wp-dom-js"></script>
<script src="../wp-includes/js/dist/vendor/react-dom.min7a3b.js?ver=18.2.0" id="react-dom-js"></script>
<script src="../wp-includes/js/dist/escape-html.min3a9d.js?ver=6561a406d2d232a6fbd2" id="wp-escape-html-js"></script>
<script src="../wp-includes/js/dist/element.min1596.js?ver=cb762d190aebbec25b27" id="wp-element-js"></script>
<script src="../wp-includes/js/dist/is-shallow-equal.mincb09.js?ver=e0f9f1d78d83f5196979" id="wp-is-shallow-equal-js"></script>
<script src="../wp-includes/js/dist/keycodes.min8cc0.js?ver=034ff647a54b018581d3" id="wp-keycodes-js"></script>
<script src="../wp-includes/js/dist/priority-queue.minc7db.js?ver=9c21c957c7e50ffdbf48" id="wp-priority-queue-js"></script>
<script src="../wp-includes/js/dist/compose.minda6c.js?ver=1339d3318cd44440dccb" id="wp-compose-js"></script>
<script src="../wp-includes/js/dist/private-apis.min2c22.js?ver=5e7fdf55d04b8c2aadef" id="wp-private-apis-js"></script>
<script src="../wp-includes/js/dist/redux-routine.minc63d.js?ver=b14553dce2bee5c0f064" id="wp-redux-routine-js"></script>
<script src="../wp-includes/js/dist/data.minff3d.js?ver=e6595ba1a7cd34429f66" id="wp-data-js"></script>
<script id="wp-data-js-after">
  (function() {
    var userId = 0;
    var storageKey = "WP_DATA_USER_" + userId;
    wp.data.use(wp.data.plugins.persistence, {
      storageKey: storageKey
    });
  })();
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-registry787e.js?ver=1714985922" id="wc-blocks-registry-js"></script>
<script src="../wp-includes/js/dist/data-controls.min01e0.js?ver=49f5587e8b90f9e7cc7e" id="wp-data-controls-js"></script>
<script src="../wp-includes/js/dist/html-entities.min5b55.js?ver=2cd3358363e0675638fb" id="wp-html-entities-js"></script>
<script src="../wp-includes/js/dist/notices.minfe2f.js?ver=673a68a7ac2f556ed50b" id="wp-notices-js"></script>
<script id="wc-blocks-middleware-js-before">
  var wcBlocksMiddlewareConfig = {
    storeApiNonce: "18f5ee9ec3",
    wcStoreApiNonceTimestamp: "1721491858",
  };
</script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-middleware787e.js?ver=1714985922" id="wc-blocks-middleware-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-data787e.js?ver=1714985922" id="wc-blocks-data-store-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter-frontend787e.js?ver=1714985922" id="wc-price-filter-block-frontend-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce-currency-switcher/js/price-filter-frontend787e.js?ver=1714985922" id="wc-price-filter-frontend-js"></script>
<script src="../wp-content/plugins/woocommerce-currency-switcher/js/jquery.ddslick.min2fca.js?ver=1.4.0" id="jquery.ddslick.min-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/woocommerce-currency-switcher/js/front787e.js?ver=1714985922" id="woocommerce-currency-switcher-js"></script>
<script src="../wp-content/plugins/elementor/assets/js/webpack.runtime.min6319.js?ver=3.15.2" id="elementor-webpack-runtime-js"></script>
<script src="../wp-content/plugins/elementor/assets/js/frontend-modules.min6319.js?ver=3.15.2" id="elementor-frontend-modules-js"></script>
<script src="../wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script id="elementor-frontend-js-before">
  var elementorFrontendConfig = {
    environmentMode: {
      edit: false,
      wpPreview: false,
      isScriptDebug: false,
    },
    i18n: {
      shareOnFacebook: "Share on Facebook",
      shareOnTwitter: "Share on Twitter",
      pinIt: "Pin it",
      download: "Download",
      downloadImage: "Download image",
      fullscreen: "Fullscreen",
      zoom: "Zoom",
      share: "Share",
      playVideo: "Play Video",
      previous: "Previous",
      next: "Next",
      close: "Close",
      a11yCarouselWrapperAriaLabel: "Carousel | Horizontal scrolling: Arrow Left & Right",
      a11yCarouselPrevSlideMessage: "Previous slide",
      a11yCarouselNextSlideMessage: "Next slide",
      a11yCarouselFirstSlideMessage: "This is the first slide",
      a11yCarouselLastSlideMessage: "This is the last slide",
      a11yCarouselPaginationBulletMessage: "Go to slide",
    },
    is_rtl: false,
    breakpoints: {
      xs: 0,
      sm: 480,
      md: 768,
      lg: 1025,
      xl: 1440,
      xxl: 1600
    },
    responsive: {
      breakpoints: {
        mobile: {
          label: "Mobile Portrait",
          value: 767,
          default_value: 767,
          direction: "max",
          is_enabled: true,
        },
        mobile_extra: {
          label: "Mobile Landscape",
          value: 880,
          default_value: 880,
          direction: "max",
          is_enabled: true,
        },
        tablet: {
          label: "Tablet Portrait",
          value: 1024,
          default_value: 1024,
          direction: "max",
          is_enabled: true,
        },
        tablet_extra: {
          label: "Tablet Landscape",
          value: 1200,
          default_value: 1200,
          direction: "max",
          is_enabled: true,
        },
        laptop: {
          label: "Laptop",
          value: 1440,
          default_value: 1366,
          direction: "max",
          is_enabled: true,
        },
        widescreen: {
          label: "Widescreen",
          value: 2400,
          default_value: 2400,
          direction: "min",
          is_enabled: false,
        },
      },
    },
    version: "3.15.2",
    is_static: false,
    experimentalFeatures: {
      e_dom_optimization: true,
      e_optimized_assets_loading: true,
      additional_custom_breakpoints: true,
      container: true,
      "landing-pages": true,
      "nested-elements": true,
    },
    urls: {
      assets: "https:\/\/demo2.pavothemes.com\/printec\/wp-content\/plugins\/elementor\/assets\/",
    },
    swiperClass: "swiper-container",
    settings: {
      page: [],
      editorPreferences: []
    },
    kit: {
      active_breakpoints: [
        "viewport_mobile",
        "viewport_mobile_extra",
        "viewport_tablet",
        "viewport_tablet_extra",
        "viewport_laptop",
      ],
      viewport_laptop: 1440,
      global_image_lightbox: "yes",
      lightbox_enable_counter: "yes",
      lightbox_enable_fullscreen: "yes",
      lightbox_enable_zoom: "yes",
      lightbox_enable_share: "yes",
      lightbox_title_src: "title",
      lightbox_description_src: "description",
    },
    post: {
      id: 142,
      title: "Home%207%20%E2%80%93%20Printec",
      excerpt: "",
      featuredImage: false,
    },
  };
</script>
<script src="../wp-content/plugins/elementor/assets/js/frontend.min6319.js?ver=3.15.2" id="elementor-frontend-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/elementor/call-to-actionc135.js?ver=1714985931" id="printec-elementor-call-to-action-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/elementor/product-categoriesc135.js?ver=1714985931" id="printec-elementor-product-categories-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/elementor/tabsc135.js?ver=1714985931" id="printec-elementor-tabs-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/elementor/productsace6.js?ver=1714985956" id="printec-elementor-products-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/elementor/testimonialace6.js?ver=1714985956" id="printec-elementor-testimonial-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/elementor/brandace6.js?ver=1714985956" id="printec-elementor-brand-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/elementor/posts-gridace6.js?ver=1714985956" id="printec-elementor-posts-grid-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/plugins/make-column-clickable-elementor/assets/js/make-column-clickablec135.js?ver=1714985931" id="make-column-clickable-elementor-js"></script>
<script data-minify="1" defer src="../wp-content/cache/min/1/printec/wp-content/plugins/mailchimp-for-wp/assets/js/formsc135.js?ver=1714985931" id="mc4wp-forms-api-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/elementor-frontend787e.js?ver=1714985922" id="printec-elementor-frontend-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/vendor/jquery.sticky787e.js?ver=1714985922" id="elementor-sticky-js"></script>
<script data-minify="1" src="../wp-content/cache/min/1/printec/wp-content/themes/printec/assets/js/vendor/sticky787e.js?ver=1714985922" id="printec-elementor-sticky-js"></script>
<script id="wc-cart-fragments-js-extra">
  var wc_cart_fragments_params = {
    ajax_url: "\/printec\/wp-admin\/admin-ajax.php",
    wc_ajax_url: "\/printec\/?wc-ajax=%%endpoint%%",
    cart_hash_key: "wc_cart_hash_2deb7a9bd63e5ae15f7e2208e828b807",
    fragment_name: "wc_fragments_2deb7a9bd63e5ae15f7e2208e828b807",
    request_timeout: "5000",
  };
</script>
<script src="../wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min76d9.js?ver=8.0.2" id="wc-cart-fragments-js"></script>
<script type="rocketlazyloadscript" id="rs-initialisation-scripts">
  var	tpj = jQuery;

      var	revapi9;

      if(window.RS_MODULES === undefined) window.RS_MODULES = {};
      if(RS_MODULES.modules === undefined) RS_MODULES.modules = {};
      RS_MODULES.modules["revslider91"] = {once: RS_MODULES.modules["revslider91"]!==undefined ? RS_MODULES.modules["revslider91"].once : undefined, init:function() {
      	window.revapi9 = window.revapi9===undefined || window.revapi9===null || window.revapi9.length===0  ? document.getElementById("rev_slider_9_1") : window.revapi9;
      	if(window.revapi9 === null || window.revapi9 === undefined || window.revapi9.length==0) { window.revapi9initTry = window.revapi9initTry ===undefined ? 0 : window.revapi9initTry+1; if (window.revapi9initTry<20) requestAnimationFrame(function() {RS_MODULES.modules["revslider91"].init()}); return;}
      	window.revapi9 = jQuery(window.revapi9);
      	if(window.revapi9.revolution==undefined){ revslider_showDoubleJqueryError("rev_slider_9_1"); return;}
      	revapi9.revolutionInit({
      			revapi:"revapi9",
      			DPR:"dpr",
      			sliderLayout:"fullwidth",
      			visibilityLevels:"1240,1024,778,480",
      			gridwidth:"1470,1024,778,480",
      			gridheight:"680,650,600,550",
      			lazyType:"smart",
      			perspective:600,
      			perspectiveType:"global",
      			keepBPHeight:true,
      			editorheight:"680,650,600,550",
      			responsiveLevels:"1240,1024,778,480",
      			progressBar:{disableProgressBar:true},
      			navigation: {
      				wheelCallDelay:1000,
      				onHoverStop:false,
      				bullets: {
      					enable:true,
      					tmp:"<span class=\"tp-bullet-inner\"></span>",
      					style:"uranus",
      					v_offset:35,
      					space:15
      				}
      			},
      			viewPort: {
      				global:true,
      				globalDist:"-200px",
      				enable:false
      			},
      			fallbacks: {
      				allowHTML5AutoPlayOnAndroid:true
      			},
      	});

      }} // End of RevInitScript

      if (window.RS_MODULES.checkMinimal!==undefined) { window.RS_MODULES.checkMinimal();};
    </script>
<script>
  window.lazyLoadOptions = {
    elements_selector: "img[data-lazy-src],.rocket-lazyload",
    data_src: "lazy-src",
    data_srcset: "lazy-srcset",
    data_sizes: "lazy-sizes",
    class_loading: "lazyloading",
    class_loaded: "lazyloaded",
    threshold: 300,
    callback_loaded: function(element) {
      if (
        element.tagName === "IFRAME" &&
        element.dataset.rocketLazyload == "fitvidscompatible"
      ) {
        if (element.classList.contains("lazyloaded")) {
          if (typeof window.jQuery != "undefined") {
            if (jQuery.fn.fitVids) {
              jQuery(element).parent().fitVids();
            }
          }
        }
      }
    },
  };
  window.addEventListener(
    "LazyLoad::Initialized",
    function(e) {
      var lazyLoadInstance = e.detail.instance;
      if (window.MutationObserver) {
        var observer = new MutationObserver(function(mutations) {
          var image_count = 0;
          var iframe_count = 0;
          var rocketlazy_count = 0;
          mutations.forEach(function(mutation) {
            for (i = 0; i < mutation.addedNodes.length; i++) {
              if (
                typeof mutation.addedNodes[i].getElementsByTagName !==
                "function"
              ) {
                continue;
              }
              if (
                typeof mutation.addedNodes[i].getElementsByClassName !==
                "function"
              ) {
                continue;
              }
              images = mutation.addedNodes[i].getElementsByTagName("img");
              is_image = mutation.addedNodes[i].tagName == "IMG";
              iframes =
                mutation.addedNodes[i].getElementsByTagName("iframe");
              is_iframe = mutation.addedNodes[i].tagName == "IFRAME";
              rocket_lazy =
                mutation.addedNodes[i].getElementsByClassName(
                  "rocket-lazyload"
                );
              image_count += images.length;
              iframe_count += iframes.length;
              rocketlazy_count += rocket_lazy.length;
              if (is_image) {
                image_count += 1;
              }
              if (is_iframe) {
                iframe_count += 1;
              }
            }
          });
          if (image_count > 0 || iframe_count > 0 || rocketlazy_count > 0) {
            lazyLoadInstance.update();
          }
        });
        var b = document.getElementsByTagName("body")[0];
        var config = {
          childList: !0,
          subtree: !0
        };
        observer.observe(b, config);
      }
    },
    !1
  );
</script>
<script data-no-minify="1" async src="../wp-content/plugins/wp-rocket/assets/js/lazyload/16.1/lazyload.min.js"></script>
</body>

</html>