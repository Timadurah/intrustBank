<?php
// Start the session
session_start();

class BotPreventor
{
    private $knownBots;
    private $rateLimit;
    private $rateLimitTime;
    private $rateLimitFile;

    public function __construct($rateLimit = 5, $rateLimitTime = 60)
    {
        $this->knownBots = [
            'Googlebot',
            'Bingbot',
            'Slurp',
            'DuckDuckBot',
            'Baiduspider',
            'YandexBot',
            'Sogou',
            'Exabot',
            'facebot',
            'ia_archiver',
            'bingbot',
            'msn',
            'abacho',
            'abcdatos',
            'abcsearch',
            'acoon',
            'adsarobot',
            'aesop',
            'ah-ha',
            'alkalinebot',
            'almaden',
            'altavista',
            'antibot',
            'anzwerscrawl',
            'aol',
            'search',
            'appie',
            'arachnoidea',
            'araneo',
            'architext',
            'ariadne',
            'arianna',
            'ask',
            'jeeves',
            'aspseek',
            'asterias',
            'astraspider',
            'atomz',
            'augurfind',
            'backrub',
            'baiduspider',
            'bannana_bot',
            'bbot',
            'bdcindexer',
            'blindekuh',
            'boitho',
            'boito',
            'borg-bot',
            'bsdseek',
            'christcrawler',
            'computer_and_automation_research_institute_crawler',
            'coolbot',
            'cosmos',
            'crawler',
            'crawler@fast',
            'crawlerboy',
            'cruiser',
            'cusco',
            'cyveillance',
            'deepindex',
            'denmex',
            'dittospyder',
            'docomo',
            'dogpile',
            'dtsearch',
            'elfinbot',
            'entire',
            'web',
            'esismartspider',
            'exalead',
            'excite',
            'ezresult',
            'fast',
            'fast-webcrawler',
            'fdse',
            'felix',
            'fido',
            'findwhat',
            'finnish',
            'firefly',
            'firstgov',
            'fluffy',
            'freecrawl',
            'frooglebot',
            'galaxy',
            'gaisbot',
            'geckobot',
            'gencrawler',
            'geobot',
            'gigabot',
            'girafa',
            'goclick',
            'goliat',
            'googlebot',
            'griffon',
            'gromit',
            'grub-client',
            'gulliver',
            'gulper',
            'henrythemiragorobot',
            'hometown',
            'hotbot',
            'htdig',
            'hubater',
            'ia_archiver',
            'ibm_planetwide',
            'iitrovatore-setaccio',
            'incywincy',
            'incrawler',
            'indy',
            'infonavirobot',
            'infoseek',
            'ingrid',
            'inspectorwww',
            'intelliseek',
            'internetseer',
            'ip3000.com-crawler',
            'iron33',
            'jcrawler',
            'jeeves',
            'jubii',
            'kanoodle',
            'kapito',
            'kit_fireball',
            'kit-fireball',
            'ko_yappo_robot',
            'kototoi',
            'lachesis',
            'larbin',
            'legs',
            'linkwalker',
            'lnspiderguy',
            'look.com',
            'lycos',
            'mantraagent',
            'markwatch',
            'maxbot',
            'mercator',
            'merzscope',
            'meshexplorer',
            'metacrawler',
            'mirago',
            'mnogosearch',
            'moget',
            'motor',
            'muscatferret',
            'nameprotect',
            'nationaldirectory',
            'naverrobot',
            'nazilla',
            'ncsa',
            'beta',
            'netnose',
            'netresearchserver',
            'ng/1.0',
            'northerlights',
            'npbot',
            'nttdirectory_robot',
            'nutchorg',
            'nzexplorer',
            'odp',
            'openbot',
            'openfind',
            'osis-project',
            'overture',
            'perlcrawler',
            'phpdig',
            'pjspide',
            'polybot',
            'pompos',
            'poppi',
            'portalb',
            'psbot',
            'quepasacreep',
            'rabot',
            'raven',
            'rhcs',
            'robi',
            'robocrawl',
            'robozilla',
            'roverbot',
            'scooter',
            'scrubby',
            'search.ch',
            'search.com.ua',
            'searchfeed',
            'searchspider',
            'searchuk',
            'seventwentyfour',
            'sidewinder',
            'sightquestbot',
            'skymob',
            'sleek',
            'slider_search',
            'slurp',
            'solbot',
            'speedfind',
            'speedy',
            'spida',
            'spider_monkey',
            'spiderku',
            'stackrambler',
            'steeler',
            'suchbot',
            'suchknecht.at-robot',
            'suntek',
            'szukacz',
            'surferf3',
            'surfnomore',
            'surveybot',
            'suzuran',
            'synobot',
            'tarantula',
            'teomaagent',
            'teradex',
            't-h-u-n-d-e-r-s-t-o-n-e',
            'tigersuche',
            'topiclink',
            'toutatis',
            'tracerlock',
            'turnitinbot',
            'tutorgig',
            'uaportal',
            'uasearch.kiev.ua',
            'uksearcher',
            'ultraseek',
            'unitek',
            'vagabondo',
            'verygoodsearch',
            'vivisimo',
            'voilabot',
            'voyager',
            'vscooter',
            'w3index',
            'w3c_validator',
            'wapspider',
            'wdg_validator',
            'webcrawler',
            'webmasterresourcesdirectory',
            'webmoose',
            'websearchbench',
            'webspinne',
            'whatuseek',
            'whizbanglab',
            'winona',
            'wire',
            'wotbox',
            'wscbot',
            'www.webwombat.com.au',
            'xenu',
            'link',
            'sleuth',
            'xyro',
            'yahoobot',
            'yahoo!',
            'slurp',
            'yandex',
            'yellopet-spider',
            'zao/0',
            'zealbot',
            'zippy',
            'zyborg',
            'mediapartners-google'

        ];
        $this->rateLimit = $rateLimit;
        $this->rateLimitTime = $rateLimitTime;
        @$this->rateLimitFile = __DIR__ . "/rate_limit_" . $this->getIp() . ".txt";
    }

    public function checkBot()
    {
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        foreach ($this->knownBots as $bot) {
            if (stripos($userAgent, $bot) !== false) {
                header('HTTP/1.0 403 Forbidden');
                header('Location: ./cloudflare');
            }
        }
    }

    public function checkRateLimit()
    {
        if (file_exists($this->rateLimitFile)) {
            $rateData = file_get_contents($this->rateLimitFile);
            list($attempts, $lastAttemptTime) = explode('|', $rateData);
            if ($attempts >= $this->rateLimit && (time() - $lastAttemptTime) < $this->rateLimitTime) {
                header('Location: ./cloudflare');
            }
        }
    }

    public function incrementRateLimit()
    {
        if (file_exists($this->rateLimitFile)) {
            list($attempts, $lastAttemptTime) = explode('|', file_get_contents($this->rateLimitFile));
            $attempts++;
        } else {
            $attempts = 1;
        }
        @file_put_contents($this->rateLimitFile, "$attempts|" . time());
    }

    private function getIp()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }
}


// run the bot

$botPreventor = new BotPreventor();
$botPreventor->checkBot();
$botPreventor->checkRateLimit();
$botPreventor->incrementRateLimit();


// Check if the user has already passed the Cloudflare challenge
if (!isset($_SESSION['cf_challenge_passed'])) {
    // Redirect to the path that triggers the Cloudflare challenge
    header('Location: ./cloudflare');
    // exit;
}
