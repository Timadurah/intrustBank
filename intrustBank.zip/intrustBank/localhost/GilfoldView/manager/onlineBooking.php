
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -5%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -5;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -5%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -0%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -10%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: 10%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: 10;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 0%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 0%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 4ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 6ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 1ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 5ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 1ch;
        height: 10ch;
        position: abs
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: white;
        width: 5ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -7%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -5%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -5;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -5%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -0%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: -10%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: 10%;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: 10;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 50%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 0%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 0%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 4ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 5ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 6ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 1ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 6ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 5ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    
        content: "";
        border-radius: 100% 0% 100% 0% / 100% 59% 41% 0%;
        background: black;
        width: 1ch;
        height: 10ch;
        position: absolute;
        top: 30%;
        left: 0;
    